package com.iamxam.gettersetter;

public class UserMessageData {

	private String strChatRow_NickName;
	private String strChatRow_FullDesc;
	private String strChatRow_Time;
	private String strChatRow_Badge;
	private String strChatRow_UserImage;
	
	public String getStrChatRow_NickName() {
		return strChatRow_NickName;
	}
	public void setStrChatRow_NickName(String strChatRow_NickName) {
		this.strChatRow_NickName = strChatRow_NickName;
	}
	public String getStrChatRow_FullDesc() {
		return strChatRow_FullDesc;
	}
	public void setStrChatRow_FullDesc(String strChatRow_FullDesc) {
		this.strChatRow_FullDesc = strChatRow_FullDesc;
	}
	public String getStrChatRow_Time() {
		return strChatRow_Time;
	}
	public void setStrChatRow_Time(String strChatRow_Time) {
		this.strChatRow_Time = strChatRow_Time;
	}
	public String getStrChatRow_Badge() {
		return strChatRow_Badge;
	}
	public void setStrChatRow_Badge(String strChatRow_Badge) {
		this.strChatRow_Badge = strChatRow_Badge;
	}
	public String getStrChatRow_UserImage() {
		return strChatRow_UserImage;
	}
	public void setStrChatRow_UserImage(String strChatRow_UserImage) {
		this.strChatRow_UserImage = strChatRow_UserImage;
	}
}
