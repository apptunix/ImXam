package com.iamxam.gettersetter;

public class UserChatDetailData {

	private String strUserName;
	private String strCurrentTime;
	private String strPreviousTime;
	private String strUserMessage;
	public String getStrUserName() {
		return strUserName;
	}
	public void setStrUserName(String strUserName) {
		this.strUserName = strUserName;
	}
	public String getStrCurrentTime() {
		return strCurrentTime;
	}
	public void setStrCurrentTime(String strCurrentTime) {
		this.strCurrentTime = strCurrentTime;
	}
	public String getStrPreviousTime() {
		return strPreviousTime;
	}
	public void setStrPreviousTime(String strPreviousTime) {
		this.strPreviousTime = strPreviousTime;
	}
	public String getStrUserMessage() {
		return strUserMessage;
	}
	public void setStrUserMessage(String strUserMessage) {
		this.strUserMessage = strUserMessage;
	}
	
}
