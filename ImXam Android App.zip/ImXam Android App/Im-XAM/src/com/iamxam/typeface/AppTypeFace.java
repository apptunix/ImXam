package com.iamxam.typeface;


import android.content.Context;
import android.graphics.Typeface;

/**
 * @author KISHOR SINGH <kishor@softwarejoint.com>    This is singleton class for handling fonts (Typefaces) of
 *         app
 */
public class AppTypeFace {

	public static AppTypeFace sAppTypeface;

	
	private Typeface mRobotoLight;
	private Typeface mRobotoMedium;
	private Typeface mRobotoRegular;
	
	private Context mContext;

	/**
	 * private constructor to make it singleton
	 * 
	 * @param context
	 *            to create typefaces
	 */
	private AppTypeFace(Context context) {
		if (mContext == null)
			mContext = context;
	}

	/**
	 * factory method to get instance of
	 * 
	 * @param context
	 *            Context to pass for creating typefaces
	 * @return AppTypeFace returns reference of static AppTypeFace
	 */
	public static AppTypeFace getAppTypeface(Context context) {
		if (sAppTypeface == null)
			sAppTypeface = new AppTypeFace(context);
		return sAppTypeface;
	}

	/**
	 * @param void
	 * @return return Typeface object of RobotoLight
	 */
	public Typeface getTypeFaceRobotoLight() {
		if (mRobotoLight == null) {
			mRobotoLight = Typeface.createFromAsset(mContext.getAssets(), "fonts/roboto_light.ttf");
		}
		return mRobotoLight;
	}

	/**
	 * @param void
	 * @return return Typeface object of RobotoMedium
	 */
	public Typeface getTypeFaceRobotoMedium() {
		if (mRobotoMedium == null) {
			mRobotoMedium = Typeface.createFromAsset(mContext.getAssets(), "fonts/roboto_medium.ttf");
		}
		return mRobotoMedium;
	}

	/**
	 * @param void
	 * @return return Typeface object of RobotoRegular
	 */
	public Typeface getTypeFaceRobotoRegular() {
		if (mRobotoRegular == null) {
			mRobotoRegular = Typeface.createFromAsset(mContext.getAssets(), "fonts/roboto_regular.ttf");
		}
		return mRobotoRegular;
	}

	
}
