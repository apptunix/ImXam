package com.iamxam.second.widget;

public class ContactItemException extends Exception {

	public ContactItemException(){}
	public ContactItemException(String msg){
		super(msg);
	}
	
	
}
