package com.iamxam.activity;

import java.util.ArrayList;
import java.util.List;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;

import com.fortysevendeg.swipelistview.BaseSwipeListViewListener;
import com.fortysevendeg.swipelistview.SwipeListView;
import com.iamxam.R;
import com.iamxam.adapter.UserAdapter;
import com.iamxam.fragments.NewCircleFragment;
import com.iamxam.fragments.QviteFragement;
import com.iamxam.fragments.UserChatDetail;
import com.iamxam.fragments.VoteFragment;
import com.iamxam.gettersetter.UserMessageData;

public class Chat extends android.support.v4.app.Fragment implements
		OnClickListener {

	private Fragment fragment;

	private static final int STATE_ONSCREEN = 0;
	SwipeListView swipelistview;
	UserAdapter adapter;
	List<UserMessageData> itemData;
	public ArrayList<UserMessageData> search_data = new ArrayList<UserMessageData>();

	public static Chat newInstance() {
		Chat chat = new Chat();
		return chat;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.activity_main, container, false);

		swipelistview = (SwipeListView) view
				.findViewById(R.id.example_swipe_lv_list);
		itemData = new ArrayList<UserMessageData>();
		adapter = new UserAdapter(getActivity(), R.layout.custom_row, itemData);

		initialiseLayoutVariables(view);
		
		swipelistview.setSwipeListViewListener(new BaseSwipeListViewListener() {
			@Override
			public void onOpened(int position, boolean toRight) {
			}

			@Override
			public void onClosed(int position, boolean fromRight) {
			}

			@Override
			public void onListChanged() {
			}

			@Override
			public void onMove(int position, float x) {
			}

			@Override
			public void onStartOpen(int position, int action, boolean right) {
				Log.d("swipe", String.format("onStartOpen %d - action %d",
						position, action));
			}

			@Override
			public void onStartClose(int position, boolean right) {
				Log.d("swipe", String.format("onStartClose %d", position));
			}

			@Override
			public void onClickFrontView(int position) {
				Log.d("swipe", String.format("onClickFrontView %d", position));
				fragment = UserChatDetail.newInstance(itemData.get(position)
						.getStrChatRow_NickName());
				changeFragmentView(fragment);
				// swipelistview.openAnimate(position); //when you touch front
				// view it will open

			}

			@Override
			public void onClickBackView(int position) {
				Log.d("swipe", String.format("onClickBackView %d", position));

				// swipelistview.closeAnimate(position);//when you touch back
				// view it will close
			}

			@Override
			public void onDismiss(int[] reverseSortedPositions) {

			}

		});

		// These are the swipe listview settings. you can change these
		// setting as your requirement
		swipelistview.setSwipeMode(SwipeListView.SWIPE_MODE_LEFT); // there are
																	// five
																	// swiping
																	// modes

		// swipelistview.setSwipeActionLeft(SwipeListView.SWIPE_ACTION_DISMISS);
		// //there are four swipe actions

		/*
		 * swipelistview.setOnItemClickListener(new
		 * AdapterView.OnItemClickListener() {
		 * 
		 * @Override public void onItemClick(AdapterView<?> parent, View view,
		 * int position, long id) { // TODO Auto-generated method stub fragment
		 * =
		 * UserChatDetail.newInstance(itemData.get(position).getStrChatRow_NickName
		 * ()); changeFragmentView(fragment); } });
		 */
		swipelistview.setSwipeActionRight(SwipeListView.SWIPE_ACTION_REVEAL);
		// swipelistview.setOffsetLeft(convertDpToPixel(0f)); // left side
		// offset
		// swipelistview.setOffsetRight(convertDpToPixel(80f)); // right side
		// offset

		swipelistview.setOffsetRight(convertDpToPixel(0f)); // right side offset
		swipelistview.setOffsetLeft(convertDpToPixel(120f)); // left side offset

		swipelistview.setAnimationTime(500); // Animation time
		// swipelistview.setSwipeOpenOnLongPress(true); // enable or disable
		// SwipeOpenOnLongPress

		swipelistview.setAdapter(adapter);

		for (int i = 0; i < 10; i++) {
			UserMessageData objUserMessageData = new UserMessageData();
			if (i % 2 == 0) {
				objUserMessageData.setStrChatRow_NickName("amanda");
			} else {
				objUserMessageData.setStrChatRow_NickName("Aleks");
			}
			objUserMessageData
					.setStrChatRow_FullDesc("I won't be able to come");
			objUserMessageData.setStrChatRow_Time("3:21 PM");
			objUserMessageData.setStrChatRow_Badge("99+");
			objUserMessageData.setStrChatRow_UserImage("img_url");
			itemData.add(objUserMessageData);
		}

		adapter.notifyDataSetChanged();
        
		/*
		 * swipelistview.getViewTreeObserver().addOnGlobalLayoutListener(new
		 * OnGlobalLayoutListener() {
		 * 
		 * @Override public void onGlobalLayout() { mQuickReturnHeight =
		 * mQuickReturnView.getHeight(); swipelistview.computeScrollY();
		 * 
		 * }
		 * 
		 * });
		 * 
		 * 
		 * swipelistview.setOnScrollListener(new OnScrollListener() {
		 * 
		 * @SuppressLint("NewApi")
		 * 
		 * @Override public void onScroll(AbsListView view, int
		 * firstVisibleItem, int visibleItemCount, int totalItemCount) {
		 * 
		 * mScrollY = 0; int translationY = 0;
		 * 
		 * if (swipelistview.scrollYIsComputed()) { mScrollY =
		 * mListView.getComputedScrollY(); }
		 * 
		 * int rawY = mScrollY;
		 * 
		 * switch (mState) { case STATE_OFFSCREEN: if (rawY >= mMinRawY) {
		 * mMinRawY = rawY; } else { mState = STATE_RETURNING; } translationY =
		 * rawY; break;
		 * 
		 * case STATE_ONSCREEN: if (rawY > mQuickReturnHeight) { mState =
		 * STATE_OFFSCREEN; mMinRawY = rawY; } translationY = rawY; break;
		 * 
		 * case STATE_RETURNING:
		 * 
		 * translationY = (rawY - mMinRawY) + mQuickReturnHeight;
		 * 
		 * System.out.println(translationY); if (translationY < 0) {
		 * translationY = 0; mMinRawY = rawY + mQuickReturnHeight; }
		 * 
		 * if (rawY == 0) { mState = STATE_ONSCREEN; translationY = 0; }
		 * 
		 * if (translationY > mQuickReturnHeight) { mState = STATE_OFFSCREEN;
		 * mMinRawY = rawY; } break; }
		 *//** this can be used if the build is below honeycomb **/
		/*
		 * if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.HONEYCOMB) { anim =
		 * new TranslateAnimation(0, 0, translationY, translationY);
		 * anim.setFillAfter(true); anim.setDuration(0);
		 * mQuickReturnView.startAnimation(anim); } else {
		 * mQuickReturnView.setTranslationY(translationY); }
		 * 
		 * }
		 * 
		 * @Override public void onScrollStateChanged(AbsListView view, int
		 * scrollState) { } });
		 */
		return view;
	}

	public int convertDpToPixel(float dp) {
		DisplayMetrics metrics = getResources().getDisplayMetrics();
		float px = dp * (metrics.densityDpi / 160f);
		return (int) px;
	}

	private void initialiseLayoutVariables(View view) {
		view.findViewById(R.id.bt_qvite_fragment).setOnClickListener(this);
		view.findViewById(R.id.bt_vote_fragment).setOnClickListener(this);
		view.findViewById(R.id.bt_new_circle_fragment).setOnClickListener(this);

	}

	@Override
	public void onClick(View v) {

		switch (v.getId()) {

		case R.id.bt_qvite_fragment:
			fragment = new QviteFragement();
			changeFragmentView(fragment);
			break;
		case R.id.bt_vote_fragment:
			fragment = new VoteFragment();
			changeFragmentView(fragment);
			break;
		case R.id.bt_new_circle_fragment:
			fragment = new NewCircleFragment();
			changeFragmentView(fragment);
			break;

		default:
			break;
		}
	}

	private void changeFragmentView(Fragment mFragment) 
	{
		FragmentManager fragmentManager = getActivity()
				.getSupportFragmentManager();
		FragmentTransaction fragmentTransaction = fragmentManager
				.beginTransaction();
		fragmentTransaction.replace(android.R.id.content, mFragment);
		fragmentTransaction.commit();
	}

	@Override
	public void onResume() {
		super.onResume();
		getResources();
		
		MainActivity.edt_search.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence cs, int arg1, int arg2,
					int arg3) {
				// When user changed the Text
			}

			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1,
					int arg2, int arg3) {
				// TODO Auto-generated method stub

			}

			@Override
			public void afterTextChanged(Editable s) {

				if (search_data.size() != 0) {
					search_data.clear();
				}

				String Serach = s.toString();

				if (s.toString().length() != 0) {
					// TODO Auto-generated method stub
					for (int i = 0; i < itemData.size(); i++) {

						if ((itemData.get(i).getStrChatRow_NickName()
								.toLowerCase()).contains(Serach.toString())) {
							search_data.add(itemData.get(i));
						}

					}

					adapter = new UserAdapter(getActivity(),
							R.layout.custom_row, search_data);

					swipelistview.setAdapter(adapter);

				}

				else {

					adapter = new UserAdapter(getActivity(),
							R.layout.custom_row, itemData);

					swipelistview.setAdapter(adapter);

				}

			}

		});

	}
}