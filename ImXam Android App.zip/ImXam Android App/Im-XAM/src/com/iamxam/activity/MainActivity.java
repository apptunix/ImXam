package com.iamxam.activity;

import java.lang.reflect.Field;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.astuetz.PagerSlidingTabStrip;
import com.astuetz.PagerSlidingTabStrip.IconTabProvider;
import com.iamxam.R;
import com.iamxam.appconstant.Appconstants;
import com.iamxam.fragments.AlertFragment;
import com.iamxam.fragments.ContactFragment;
import com.iamxam.fragments.SettingFragement;
import com.iamxam.widget.FixedSpeedScroller;

public class MainActivity extends FragmentActivity {

	private static final String TAG = "FragmentActivity";
	private PagerSlidingTabStrip tabs;
	private ViewPager pager;
	private ContactPager adapter;
	TextView txt_header;
	public static Boolean SearchClick = false;
	public static EditText edt_search;

	@Override
	protected void onCreate(Bundle arg0) {
		super.onCreate(arg0);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main_layout);

		initialiseLayoutVariables();
		setScroolingOfViewPagerSmooth(pager);

		// check for intents
		if (getIntent() != null && getIntent().getExtras() != null) {
			Bundle bundle = getIntent().getExtras();
			int currentTab = bundle.getInt(Appconstants.TO_WHICH_TAB);
			changeTabIcon(currentTab);
			pager.setCurrentItem(currentTab);
		} else {
			changeTabIcon(0);
			pager.setCurrentItem(0);
		}

		tabs.setOnPageChangeListener(new OnPageChangeListener() {

			@Override
			public void onPageSelected(final int position) {
				// changeTabIcon(position);
				tabs.postDelayed(new Runnable() {

					@Override
					public void run() {
						changeTabIcon(position);
					}
				}, 380);
			}

			@Override
			public void onPageScrolled(int position, float positionOffset,
					int positionOffsetPixels) {

			}

			@Override
			public void onPageScrollStateChanged(int state) {
				if (state == ViewPager.SCROLL_STATE_IDLE) {
					Log.e("SCROLL_STATE_IDLE", "SCROLL_STATE_IDLE");
					pager.setEnabled(true);
				} else if (state == ViewPager.SCROLL_STATE_SETTLING) {
					pager.setEnabled(false);
				}

			}
		});
	}

	private void initialiseLayoutVariables() {
		tabs = (PagerSlidingTabStrip) findViewById(R.id.tabs);
		pager = (ViewPager) findViewById(R.id.pager);
		adapter = new ContactPager(getSupportFragmentManager());
		pager.setAdapter(adapter);
		tabs.setViewPager(pager);
		tabs.setSmoothScrollingEnabled(true);
		pager.setOffscreenPageLimit(4);
		/*
		 * pager.setPageTransformer(true, new PageTransformer() {
		 * 
		 * @Override public void transformPage(View arg0, float arg1) { // TODO
		 * Auto-generated method stub
		 * 
		 * } });
		 */

	}

	private void setScroolingOfViewPagerSmooth(ViewPager mPager) {
		try {
			Field mScroller;
			mScroller = ViewPager.class.getDeclaredField("mScroller");
			mScroller.setAccessible(true);
			FixedSpeedScroller scroller = new FixedSpeedScroller(
					mPager.getContext());
			mScroller.set(mPager, scroller);
		} catch (NoSuchFieldException e) {
		} catch (IllegalArgumentException e) {
		} catch (IllegalAccessException e) {
		}

	}

	private void changeTabIcon(int currentTab) {
		switch (currentTab) {
		case 0:
			initiliaseHeaderLayout(0);
			tabs.setTabIcon(0, R.drawable.ic_alert_active);
			tabs.setTabIcon(1, R.drawable.ic_chat_inactive);
			tabs.setTabIcon(2, R.drawable.ic_contact_inactive);
			tabs.setTabIcon(3, R.drawable.ic_setting_inactive);
			break;
		case 1:
			initiliaseHeaderLayout(1);
			edt_search.setText("");
			tabs.setTabIcon(0, R.drawable.ic_alert_inactive);
			tabs.setTabIcon(1, R.drawable.ic_chat_active);
			tabs.setTabIcon(2, R.drawable.ic_contact_inactive);
			tabs.setTabIcon(3, R.drawable.ic_setting_inactive);

			// changeLaout(getLayout(1));
			break;
		case 2:
			initiliaseHeaderLayout(2);
			edt_search.setText("");
			tabs.setTabIcon(0, R.drawable.ic_alert_inactive);
			tabs.setTabIcon(1, R.drawable.ic_chat_inactive);
			tabs.setTabIcon(2, R.drawable.ic_contact_active);
			tabs.setTabIcon(3, R.drawable.ic_setting_inactive);
			break;
		case 3:
			initiliaseHeaderLayout(3);
			tabs.setTabIcon(0, R.drawable.ic_alert_inactive);
			tabs.setTabIcon(1, R.drawable.ic_chat_inactive);
			tabs.setTabIcon(2, R.drawable.ic_contact_inactive);
			tabs.setTabIcon(3, R.drawable.ic_setting_active);
			animateImage(tabs.getTabIcon(3));
			break;
		}
	}

	private void initiliaseHeaderLayout(int position) {

		ImageView image = (ImageView) findViewById(R.id.iv_back);
		edt_search = (EditText) findViewById(R.id.edt_srch);
		edt_search.setVisibility(View.GONE);
		image.setVisibility(View.GONE);

		txt_header = (TextView) findViewById(R.id.tv_header_back_text);
		txt_header.setVisibility(View.INVISIBLE);

		TextView txt_common = (TextView) findViewById(R.id.tv_common);
		txt_common.setVisibility(View.INVISIBLE);

		final TextView tv_header = (TextView) findViewById(R.id.tv_header);
		ImageView imgSearch = (ImageView) findViewById(R.id.img_srch);

		TextView txt_Edit = (TextView) findViewById(R.id.txt_edit);
		imgSearch.setImageResource(R.drawable.ic_serach_loc);
		imgSearch.setVisibility(View.GONE);
		txt_Edit.setVisibility(View.GONE);
		switch (position) {
		case 0:
			tv_header.setText(R.string.txt_xml_alert);
			tv_header.setVisibility(View.VISIBLE);
			break;
		case 1:
			tv_header.setText(R.string.txt_tab_chat);
			imgSearch.setVisibility(View.VISIBLE);
			txt_Edit.setVisibility(View.VISIBLE);
			tv_header.setVisibility(View.VISIBLE);
			imgSearch.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub

					if (SearchClick == true) {

						SearchClick = false;
						tv_header.setVisibility(View.VISIBLE);
						edt_search.setVisibility(View.GONE);
						edt_search.setText("");
					} else {
						SearchClick = true;
						tv_header.setVisibility(View.GONE);
						edt_search.setVisibility(View.VISIBLE);
					}
				}
			});
			break;
		case 2:
			image.setVisibility(View.VISIBLE);
			image.setImageResource(R.drawable.ic_serach_loc);
			tv_header.setVisibility(View.VISIBLE);

			image.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					if (SearchClick == true) {

						SearchClick = false;
						tv_header.setVisibility(View.VISIBLE);
						edt_search.setVisibility(View.GONE);
						edt_search.setText("");
					} else {
						SearchClick = true;
						tv_header.setVisibility(View.GONE);
						edt_search.setVisibility(View.VISIBLE);
					}

				}
			});
			tv_header.setText(R.string.txt_tab_contact);
			imgSearch.setImageResource(R.drawable.ic_add);
			imgSearch.setVisibility(View.VISIBLE);
			break;
		case 3:
			tv_header.setText(R.string.txt_tab_setting);
			tv_header.setVisibility(View.VISIBLE);
			break;
		default:
			break;
		}
	}

	
	public static  void clrEditText(){
		edt_search.setText("");
		
		
	}
	public class ContactPager extends FragmentPagerAdapter implements
			IconTabProvider {

		private final int[] ICONS = { R.drawable.ic_alert_inactive,
				R.drawable.ic_chat_inactive, R.drawable.ic_contact_inactive,
				R.drawable.ic_setting_inactive };

		public ContactPager(FragmentManager fm) {
			super(fm);

		}

		@Override
		public int getPageIconResId(int position) {
			return ICONS[position];
		}

		@Override
		public android.support.v4.app.Fragment getItem(int position) {
			android.support.v4.app.Fragment mFragment = AlertFragment
					.newInstance();
			switch (position) {
			case 0:
				edt_search.setText("");
				mFragment = AlertFragment.newInstance();
				break;
			case 1:
				edt_search.setText("");
				mFragment = Chat.newInstance();
				break;
			case 2:
				edt_search.setText("");
				mFragment = ContactFragment.newInstance();
				break;
			case 3:
				edt_search.setText("");
				mFragment = SettingFragement.newInstance();
				break;
			}
			return mFragment;
		}

		@Override
		public int getCount() {
			return ICONS.length;
		}
	}

	@SuppressLint("NewApi")
	public void animateImage(ImageButton img_bt) {
		ObjectAnimator fadeOut = ObjectAnimator.ofFloat(img_bt, "alpha", 1f,
				.3f);
		fadeOut.setDuration(2000);
		ObjectAnimator fadeIn = ObjectAnimator
				.ofFloat(img_bt, "alpha", .3f, 1f);
		fadeIn.setDuration(2000);

		final AnimatorSet mAnimationSet = new AnimatorSet();

		mAnimationSet.play(fadeIn).after(fadeOut);

		mAnimationSet.addListener(new AnimatorListenerAdapter() {
			@Override
			public void onAnimationEnd(Animator animation) {
				super.onAnimationEnd(animation);
				// mAnimationSet.start();
			}
		});
		mAnimationSet.start();
	}
}
