package com.iamxam.activity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.iamxam.R;
import com.iamxam.animation.Typewriter;
import com.iamxam.fragments.LoginHelper;
import com.iamxam.fragments.Signuphelper;
import com.iamxam.internet.ConnectionDetector;
import com.iamxam.typeface.AppTypeFace;
import com.iamxam.websockethelper.WebSocketHelper;

public class LandingActivity extends FragmentActivity implements OnClickListener {


	private static Context context;
	private AppTypeFace mAppTypeFace;
	private Typeface mRobotoMedium, mRobotoRegular;
//	AlphaAnimation fadeOut,fadeIn,fadeOut2,fadeIn2;
	//TextView  tv_bottom_copyright;
Typewriter tv_logo_text1,tv_logo_text2;
	Button bt_signup, bt_login;
	ImageView img_logowhite;
	Animation fadeIn,fadeOut;
	
	
	private FragmentManager fragmentManager;

	Fragment fragement ;
	
	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_landing_page);
		initializevariables();
		initializelayoutvariables();
		if(ConnectionDetector.isConnectingToInternet(this)){
		WebSocketHelper.makeConnection();
		}else{
			Toast.makeText(this,"No internet connection" ,0).show();
		}
	}
	
	 /*@Override
	    public void onConfigurationChanged(Configuration newConfig) {
	        super.onConfigurationChanged(newConfig);
	        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
	        	setContentView(R.layout.activity_landing_page);
	        	initializevariables();
	    		initializelayoutvariables();	
	        	
	        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT){
	        	setContentView(R.layout.activity_landing_page);
	        	initializevariables();
	    		initializelayoutvariables();	
	        }
	    }*/
	 
	 
	
	private void initializevariables() {
		context = this;
		mAppTypeFace = AppTypeFace.getAppTypeface(context);
		mRobotoMedium = mAppTypeFace.getTypeFaceRobotoMedium();
		mRobotoRegular = mAppTypeFace.getTypeFaceRobotoRegular();
				
		fragmentManager = getSupportFragmentManager();
		
	}

	@SuppressLint("NewApi")
	private void initializelayoutvariables() {

		

		tv_logo_text1 = (Typewriter) findViewById(R.id.tv_landing_logo1);
		tv_logo_text2 = (Typewriter) findViewById(R.id.tv_landing_logo2);
		
	//	tv_bottom_copyright = (TextView) findViewById(R.id.tv_landing_bottom);
		bt_signup = (Button) findViewById(R.id.bt_landing_signup);
		bt_login = (Button) findViewById(R.id.bt_landing_login);

		tv_logo_text1.setTypeface(mRobotoMedium);
		tv_logo_text2.setTypeface(mRobotoMedium);
		
	//	tv_bottom_copyright.setTypeface(mRobotoRegular);
		bt_signup.setTypeface(mRobotoMedium);
		bt_login.setTypeface(mRobotoMedium);
		
		img_logowhite=(ImageView)findViewById(R.id.img_logowhite);
		
		
		fadeIn = new AlphaAnimation(0f, 1f);
		fadeIn.setInterpolator(new DecelerateInterpolator()); //add this
		fadeIn.setDuration(2000);
		fadeOut = new AlphaAnimation(0f, 0f);
		fadeOut.setInterpolator(new DecelerateInterpolator()); //add this
		fadeOut.setDuration(1000);
		 
		fadeOut.setAnimationListener(new AnimationListener() {
			
			@Override
			public void onAnimationStart(Animation animation) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onAnimationRepeat(Animation animation) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onAnimationEnd(Animation animation) {
				// TODO Auto-generated method stub
				img_logowhite.startAnimation(fadeIn);
			}
		});
		
		fadeIn.setAnimationListener(new AnimationListener() {
			
			@Override
			public void onAnimationStart(Animation animation) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onAnimationRepeat(Animation animation) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onAnimationEnd(Animation animation) {
				// TODO Auto-generated method stub
				 tv_logo_text1.setCharacterDelay(60);		
			     tv_logo_text1.animateText(getResources().getString(R.string.txt_landing_logo1));
			     tv_logo_text2.postDelayed(new Runnable() {
			    	 public void run() {
			    		 tv_logo_text2.setCharacterDelay(60);
							tv_logo_text2.animateText("I'm XAM, who are you?");
			    	 }
			    	 }, 2000);
			}
		});
		
		img_logowhite.startAnimation(fadeOut);
		
		
		
		//set fade in fade out animation on text views
		 
		
		
		
		
		//set letter by letter animation to text views
		//tv_logo_text1.setText(R.string.txt_landing_logo1);
       // tv_logo_text2.setText("I'm XAM, who are you?");
       
        
		/*String copyright = "Copyright ";		
		String copyright_text_middle = "\u00a9";		
		tv_bottom_copyright.setText(copyright + copyright_text_middle + " 2014 I\'m XAM Inc. All right reserved.");
*/
		 
		 
		bt_signup.setOnClickListener(this);
		bt_login.setOnClickListener(this);

		/*try {
			findViewById(R.id.iv_landing_background).setBackgroundDrawable(AppUtils.getAssetImage(this, "bg_land"));
		} catch (IOException e) {
			e.printStackTrace();
		}*/

	}

	@Override
	public void onClick(View v) {

		switch (v.getId()) {
		case R.id.bt_landing_login:

			/*Intent intent = new Intent(LandingActivity.this, LoginActivity.class);
			intent.putExtra(Appconstants.INTENT_FROM, Appconstants.LOGIN);
			startActivity(intent);
			finish();*/
			
			fragement = new LoginHelper();
			FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
			fragmentTransaction.replace(android.R.id.content, fragement);
			fragmentTransaction.addToBackStack("login");
			fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
			fragmentTransaction.commit();
			
			break;

		case R.id.bt_landing_signup:
			/*Intent intent_sign = new Intent(LandingActivity.this, LoginActivity.class);
			intent_sign.putExtra(Appconstants.INTENT_FROM, Appconstants.SIGNUP);
			startActivity(intent_sign);
			finish();*/
			

			fragement = new Signuphelper();
			FragmentTransaction fragmentTransaction1 = fragmentManager.beginTransaction();
			fragmentTransaction1.replace(android.R.id.content, fragement);
			fragmentTransaction1.addToBackStack("signup");
			fragmentTransaction1.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
			fragmentTransaction1.commit();
			
			break;
		default:
			break;
		}

	}
	/*private static final WebSocket mConnection1 = new WebSocketConnection();
	 
	 public static void makeConnection1() {

	      final String wsuri = Appconstants.WEBSOCKETURI;


	      try {
	         mConnection1.connect(wsuri, new WebSocketConnectionHandler() {
	            @Override
	            public void onOpen() {
	            	 Log.d("ImXam","open");
	            }

	            @Override
	            public void onTextMessage(String payload) {
	              // alert("Got echo: " + payload);
	            	     		            	
	            }

	            @Override
	            public void onClose(int code, String reason) {
	            	 Log.d("ImXam", "close");
	            }
	         });
	      } catch (WebSocketException e) {

	         Log.d("ImXam", e.toString());
	      }
	   }

public static void sendRequest(String payload){
	
}*/

}
