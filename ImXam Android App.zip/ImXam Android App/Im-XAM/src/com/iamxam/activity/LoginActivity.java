package com.iamxam.activity;


import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.Window;

import com.iamxam.R;
import com.iamxam.appconstant.Appconstants;
import com.iamxam.fragments.LoginHelper;
import com.iamxam.fragments.Signuphelper;

public class LoginActivity extends FragmentActivity{
	
	private FragmentManager fragmentManager;
	private FragmentTransaction fragmentTransaction;
	
	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_login_signup);
		
		Bundle extra = null;
		if(getIntent() != null){
			extra = getIntent().getExtras();
		}
		initiliseLayoutvariables();
		Fragment fragement ;		
		if(extra == null){
			return;
		}else if(extra.getString(Appconstants.INTENT_FROM).equals(Appconstants.LOGIN)){
			fragement = new LoginHelper();
			fragmentTransaction.replace(android.R.id.content, fragement);
			fragmentTransaction.addToBackStack("login");
			fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
			
		}else if(extra.getString(Appconstants.INTENT_FROM).equals(Appconstants.SIGNUP)){
			fragement = new Signuphelper();
			fragmentTransaction.replace(android.R.id.content, fragement);
			fragmentTransaction.addToBackStack("signup");
			fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
		}		
		fragmentTransaction.commit();		
		
	}

	@SuppressLint("NewApi")
	private void initiliseLayoutvariables() {
		fragmentManager = getSupportFragmentManager();
		fragmentTransaction = fragmentManager.beginTransaction();
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();
		finish();
	}

	
	

}
