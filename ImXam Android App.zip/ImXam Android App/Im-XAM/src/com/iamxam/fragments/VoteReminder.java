package com.iamxam.fragments;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.iamxam.R;
import com.iamxam.apputils.AppUtils;

public class VoteReminder extends Fragment implements OnClickListener{
	private Fragment mFragement;
	private TextView tv_setting;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_setting_vote_reminder, container, false);
		initiliaseHeaderLayout(view);
		return view;
	}

	@Override
	public void onClick(View v) {
		
		switch (v.getId()) {
		case R.id.iv_back:
			tv_setting.setVisibility(View.GONE);		
			AppUtils.startSettingTab(getActivity());			
			break;
		
		case R.id.tv_header_back_text:			
			AppUtils.startSettingTab(getActivity());
		default:
			break;
		}
	}

	
	private void initiliaseHeaderLayout(View view) {

		ImageView iv_header_back = (ImageView) view.findViewById(R.id.iv_back);
		iv_header_back.setOnClickListener(this);
		
		tv_setting = (TextView) view.findViewById(R.id.tv_header_back_text);
		tv_setting.setOnClickListener(this);
		tv_setting.setVisibility(View.VISIBLE);
		
		TextView tv_header = (TextView) view.findViewById(R.id.tv_header);
		tv_header.setText(R.string.txt_vote_reminder);
	}
	
	private void changeFragmentView() {
		mFragement = new SettingFragement();
		FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
		FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
		fragmentTransaction.replace(android.R.id.content, mFragement);
		fragmentTransaction.commit();
	}
}
