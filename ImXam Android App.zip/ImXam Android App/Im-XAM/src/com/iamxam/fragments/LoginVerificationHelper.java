package com.iamxam.fragments;

import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.iamxam.R;
import com.iamxam.activity.LandingActivity;
import com.iamxam.activity.MainActivity;
import com.iamxam.appconstant.Appconstants;
import com.iamxam.internet.ConnectionDetector;
import com.iamxam.websockethelper.WebSocketHelper;

@SuppressLint("NewApi")
public class LoginVerificationHelper extends Fragment implements OnClickListener {
	private static Fragment mFragement;
	private static String str_username=null,str_firstname=null,str_email=null,str_password=null;
			
	
	static Activity activity;
	static FragmentManager fragmentManager;
	EditText et_login_verification_code;
	RelativeLayout backLayout;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.fragment_login_verification, container, false);
		initiliseHeaderLayout(view);
		return view;
	}

	private void initiliseHeaderLayout(View view) {
		ImageView iv_header_back = (ImageView) view.findViewById(R.id.iv_back);
		iv_header_back.setOnClickListener(this);
		ImageView iv_top_logo = (ImageView) view.findViewById(R.id.iv_top_logo);
		iv_top_logo.setOnClickListener(this);
		backLayout=(RelativeLayout) view.findViewById(R.id.backLayout);
		backLayout.setOnClickListener(this);
		
		activity=getActivity();	
		fragmentManager=getActivity().getSupportFragmentManager();
		
		TextView tv_common = (TextView) view.findViewById(R.id.tv_common);
		tv_common.setOnClickListener(this);
		
		TextView tv_header = (TextView) view.findViewById(R.id.tv_header);
		tv_header.setText("Sign Up");
		
		et_login_verification_code=(EditText)view.findViewById(R.id.et_login_verification_code);

	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		
		case R.id.backLayout:
			changeFragmentView();
			//getActivity().getSupportFragmentManager().beginTransaction().remove(this).commit();
			break;
		case R.id.iv_back:
			changeFragmentView();
			//getActivity().getSupportFragmentManager().beginTransaction().remove(this).commit();
			break;
		case R.id.iv_top_logo:
			/*startActivity(new Intent(getActivity(), LandingActivity.class));
			getActivity().finish();*/
			changeFragmentView();
			break;
		
		case R.id.tv_common:
			String strVerCode=et_login_verification_code.getText().toString().trim();
			String strRequestPattern="{\"type\":\"verify\",\"user\":\""+str_username+"\",\"name\":\""+str_firstname+"\",\"email\":\""+str_email+"\",\"pwd\":\""+str_password+"\",\"code\":\""+strVerCode+"\",\"id\":\"msgid\"}";
		//must uncomment it
			if(ConnectionDetector.isConnectingToInternet(activity)){
				WebSocketHelper.sendRequest(strRequestPattern, Appconstants.CLASS_LOGIN_VERIFICATION);
			Log.i("pattern",strRequestPattern);
			}else{
				Toast.makeText(activity,"No internet connection" ,0).show();
			}
			//changeViewToSplash();
			break;
		default:
			break;
		}
		
	}
	
	//go to next fragment
		public static  void goNext(){
			/*activity.startActivity(new Intent(activity, MainActivity.class));
			activity.finish();*/

			
		}
		
		//call from "WebSocketHelper" class when receive response from web socket
		public static void doAction(JSONObject jo){
			try {
				int strResponse = jo.getInt("code");
				Log.i("response code is : ", "" + strResponse);
				switch (strResponse) {
				case 0:
				//	goNext();
					String strRequestPattern1="{\"type\":\"ack\",\"id\":\"msgid\"}";
					if(ConnectionDetector.isConnectingToInternet(activity)){
					WebSocketHelper.sendRequest(strRequestPattern1, Appconstants.CLASS_LOGIN_VERIFICATION);
					changeViewToSplash();
					}else{
						Toast.makeText(activity,"No internet connection" ,0).show();
					}
					break;
				
				case 58:
					Toast.makeText(activity,
							Appconstants.hmErrorCodes.get(strResponse), 0).show();
					break;

				default:
					break;
				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 }
	
	private void changeFragmentView() {	
		
		getActivity().getSupportFragmentManager().popBackStackImmediate("signup1", FragmentManager.POP_BACK_STACK_INCLUSIVE);
		//Signuphelper.setFirstTimeVarTrue();
	}
	private static void changeViewToSplash() {
		mFragement = new SplashFragment();		
		FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
		fragmentTransaction.replace(android.R.id.content, mFragement);
		fragmentTransaction.commit();
		SplashFragment.setInputParameters(str_username, str_firstname);
		
	}
	public static void setInputParameters(String uName,String fName,String email,String password){
		str_username=uName;
		str_firstname=fName;
		str_email=email;
		str_password=password;
	}
}
