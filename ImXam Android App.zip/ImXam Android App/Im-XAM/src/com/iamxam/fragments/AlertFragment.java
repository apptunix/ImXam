package com.iamxam.fragments;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.iamxam.R;

public class AlertFragment  extends Fragment{
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_alert_layout, container, false);
		//initiliaseHeaderLayout(view);
		ListView lv = (ListView) view.findViewById(R.id.lv_alert);

		List<String> list = new ArrayList<String>();
		list.add("amanda,From, Ashley wick, Are you there?,From, Ashley wick, Are you there?");
		list.add("amanda,From, Ashley wick, Are you there?,From, Ashley wick, Are you there?");
		list.add("amanda,From, Ashley wick, Are you there?,From, Ashley wick, Are you there?");
		list.add("amanda,From, Ashley wick, Are you there?,From, Ashley wick, Are you there?");
		list.add("amanda,From, Ashley wick, Are you there?,From, Ashley wick, Are you there?");
		list.add("From, Ashley wick, Are you there?");
		list.add("amanda");
		list.add("Aleks");
		list.add("From, Ashley wick, Are you there?");
		list.add("Aleks");
		list.add("amanda");
		list.add("From, Ashley wick, Are you there?");
		list.add("amanda");
		list.add("Aleks");
		list.add("amanda");
		list.add("From, Ashley wick, Are you there?");
		list.add("amanda,From, Ashley wick, Are you there?,From, Ashley wick, Are you there?");
		list.add("Aleks");
		list.add("amanda");

		UserAdapter mUserAdapter = new UserAdapter(getActivity(), list);
		lv.setAdapter(mUserAdapter);
		return view;
	}

	public static AlertFragment newInstance() {
		AlertFragment f = new AlertFragment();
		return f;
	}

	/*private void initiliaseHeaderLayout(View view) {

		view.findViewById(R.id.iv_back).setVisibility(View.INVISIBLE);

		view.findViewById(R.id.tv_header_back_text).setVisibility(View.INVISIBLE);

		view.findViewById(R.id.tv_common).setVisibility(View.INVISIBLE);


		TextView tv_header = (TextView) view.findViewById(R.id.tv_header);
		tv_header.setText(R.string.txt_xml_alert);
	}*/

	public class UserAdapter extends BaseAdapter{

		Activity act;
		List<String> list;
		public UserAdapter(Activity act, List<String> list){
			this.act = act;
			this.list = list;
		}

		@Override
		public int getCount() {
			return list.size();
		}

		@Override
		public Object getItem(int position) {
			return position;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {

			if (convertView == null) {
				convertView = LayoutInflater.from(act).inflate(R.layout.row_alert_list_activity, parent, false);
			}

			TextView tvName = (TextView) convertView.findViewById(R.id.nickNameView);
			tvName.setText(list.get(position));
			return convertView;
		}

	}
}
