package com.iamxam.fragments;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.iamxam.R;
import com.iamxam.apputils.AppUtils;

@SuppressLint("NewApi")
public class ChangePasswordSettingFragment extends Fragment implements
		OnClickListener {

	private TextView tv_setting, tv_common, tv_forgtPasswrd;
	RelativeLayout backLayout;
	private Fragment mFragment;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.fragment_setting_reset_password,
				container, false);

		initiliaseHeaderLayout(view);
		return view;
	}

	private void initiliaseHeaderLayout(View view) {
		ImageView iv_header_back = (ImageView) view.findViewById(R.id.iv_back);
		iv_header_back.setOnClickListener(this);
		ImageView iv_top_logo = (ImageView) view.findViewById(R.id.iv_top_logo);
		iv_top_logo.setOnClickListener(this);
		backLayout=(RelativeLayout)view.findViewById(R.id.backLayout);
		backLayout.setOnClickListener(this);

		tv_setting = (TextView) view.findViewById(R.id.tv_header_back_text);
		tv_setting.setOnClickListener(this);
		tv_setting.setVisibility(View.VISIBLE);
		tv_setting.setText("Change Password");

		tv_setting = (TextView) view.findViewById(R.id.tv_header_back_text);
		tv_setting.setOnClickListener(this);
		//tv_setting.setVisibility(View.VISIBLE);

		tv_common = (TextView) view.findViewById(R.id.tv_common);
		tv_common.setText("Send");
		tv_forgtPasswrd = (TextView) view.findViewById(R.id.txt_frgtpasswrd);
		tv_forgtPasswrd.setOnClickListener(this);
		
		TextView tv_header = (TextView) view.findViewById(R.id.tv_header);
		tv_header.setText(R.string.txt_password);

	}

	@Override
	public void onClick(View v) {

		switch (v.getId()) {
		
		case R.id.backLayout:
			tv_setting.setVisibility(View.GONE);

			AppUtils.startSettingTab(getActivity());
			break;
		case R.id.iv_back:
			tv_setting.setVisibility(View.GONE);

			AppUtils.startSettingTab(getActivity());
			break;

		case R.id.tv_header_back_text:
			AppUtils.startSettingTab(getActivity());
			break;
		case R.id.txt_frgtpasswrd:
			Fragment mFragement = new ForgotPasswordFragment();

			FragmentManager fragmentManager = getActivity()
					.getSupportFragmentManager();
			FragmentTransaction fragmentTransaction = fragmentManager
					.beginTransaction();
			fragmentTransaction.replace(android.R.id.content, mFragement);
			fragmentTransaction.commit();
			break;
		default:
			break;
		}
	}

	private void changeFragmentView(Fragment fragment) {
		FragmentManager fragmentManager = getActivity()
				.getSupportFragmentManager();
		FragmentTransaction fragmentTransaction = fragmentManager
				.beginTransaction();
		fragmentTransaction.replace(android.R.id.content, fragment);
		fragmentTransaction.commit();
	}
}
