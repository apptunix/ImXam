package com.iamxam.fragments;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;

import com.iamxam.R;
import com.iamxam.animation.Typewriter;
import com.iamxam.apputils.AppUtils;

@SuppressLint("NewApi")
public class SplashFragment extends Fragment implements OnClickListener{
	
	private Typewriter tv_hi_firstname, tv_welcome_username;
	private static String str_username=null,str_firstname=null;
	Thread t;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.fragment_splash, container, false);
		initiliaseHeaderLayout(view);
		
		tv_hi_firstname.setCharacterDelay(20);		
		tv_hi_firstname.animateText("Hi "+str_firstname);
		tv_welcome_username.postDelayed(new Runnable() {
	    	 public void run() {
	    		 tv_welcome_username.setCharacterDelay(20);
	    		 tv_welcome_username.animateText("Welcome to I'm Xam your username is "+ str_username+" Enjoy");
	    	 }
	    	 }, 1500);
		try{
		 t=new Thread(r);
		t.start();
		}catch(Exception e){
			
		}
		return view;
	}

	Runnable r=new Runnable() {
		
		@Override
		public void run() {
			try {
				Thread.sleep(5000);
				AppUtils.startSettingTab(getActivity());
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// TODO Auto-generated method stub
			
		}
	};
	private void initiliaseHeaderLayout(View view) {

		TextView tv_skip = (TextView) view.findViewById(R.id.tv_skip);
		tv_skip.setOnClickListener(this);
		
		tv_hi_firstname = (Typewriter) view.findViewById(R.id.tv_hi_firstname);
		
		
		tv_welcome_username = (Typewriter) view.findViewById(R.id.tv_welcome_username);
	
		
		/*TextView tv_header = (TextView) view.findViewById(R.id.tv_header);
		tv_header.setText(R.string.txt_about);*/
	}

	@Override
	public void onClick(View v) {
		
		switch (v.getId()) {
		/*case R.id.tv_skip:
			try{
			t.stop();
				t.destroy();
			}catch(Exception e){
				
			}
			AppUtils.startSettingTab(getActivity());			
			break;*/
	
		default:
			break;
		}
		
	}
	
	public static void setInputParameters(String uName,String fName){
		str_username=uName;
		str_firstname=fName;
		
	}
	
}
