package com.iamxam.fragments;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.iamxam.R;
import com.iamxam.apputils.AppUtils;

@SuppressLint("NewApi")
public class ProfileSettingFragment  extends Fragment implements OnClickListener{
	private TextView tv_setting, tv_common;
	private Fragment mFragement;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_setting_profile, container, false);
		initiliaseHeaderLayout(view);
		return view;
	}
	
	private void initiliaseHeaderLayout(View view) {

		ImageView iv_header_back = (ImageView) view.findViewById(R.id.iv_back);
		iv_header_back.setOnClickListener(this);
		
		tv_setting = (TextView) view.findViewById(R.id.tv_header_back_text);
		tv_setting.setOnClickListener(this);
		tv_setting.setVisibility(View.VISIBLE);
		
		tv_common = (TextView) view.findViewById(R.id.tv_common);
		tv_common.setText("");
		tv_common.setBackgroundResource(R.drawable.xml_selector_edit_image);
		
		
		tv_common.setOnTouchListener(new OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if(event.getAction() == MotionEvent.ACTION_UP){

					tv_common.setEnabled(false);
		            return true;
		        }else if (event.getAction() == MotionEvent.ACTION_DOWN) {
		        	tv_common.setEnabled(true);
		        	return true;
				}
				
				return false;
			}
		});
		
		TextView tv_header = (TextView) view.findViewById(R.id.tv_header);
		tv_header.setText(R.string.txt_profile);
	}

	@Override
	public void onClick(View v) {

		switch (v.getId()) {
		case R.id.iv_back:
			tv_setting.setVisibility(View.GONE);		
			AppUtils.startSettingTab(getActivity());			
			break;
		
		case R.id.tv_header_back_text:			
			AppUtils.startSettingTab(getActivity());
			break;
			
		
			
		default:
			break;
		}
	}
	
	
}
