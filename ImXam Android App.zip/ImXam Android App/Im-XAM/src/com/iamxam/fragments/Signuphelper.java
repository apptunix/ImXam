package com.iamxam.fragments;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.SearchManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.telephony.PhoneNumberUtils;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListPopupWindow;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;

import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.PhoneNumberUtil.PhoneNumberFormat;
import com.google.i18n.phonenumbers.Phonenumber.PhoneNumber;
import com.iamxam.R;
import com.iamxam.activity.LandingActivity;
import com.iamxam.adapter.AdapterCountrySelect;
import com.iamxam.appconstant.Appconstants;
import com.iamxam.gettersetter.Country;
import com.iamxam.internet.ConnectionDetector;
import com.iamxam.models.BeanCountryCode;
import com.iamxam.util.UserEmailFetcher;
import com.iamxam.util.WordUtils;
import com.iamxam.websockethelper.WebSocketHelper;

@SuppressLint("NewApi")
public class Signuphelper extends Fragment implements OnClickListener, OnFocusChangeListener,ActionBar.OnNavigationListener {

	static boolean iFirstTime=false;
	private ActionBar actionBar;
	private Uri mImageCaptureUri;
	private static final int IMAGE_CAPTURE = 1;	
	private static final int CROP_FROM_CAMERA = 2;
	private static final int IMAGE_PICK = 3;
	private Bitmap srcBitmap;
	AlertDialog.Builder builder;
	Dialog dialogCountry;
	protected com.iamxam.adapter.CountryAdapter mAdapter;
//	public static String CountryName, CountryCode, CountryAlphaCode;
	ArrayList<BeanCountryCode> al_contry = new ArrayList<BeanCountryCode>();
	
	static String AlphaCode, country_name, country_code;

	protected SparseArray<ArrayList<Country>> mCountriesMap = new SparseArray<ArrayList<Country>>();

	protected PhoneNumberUtil mPhoneNumberUtil = PhoneNumberUtil.getInstance();
	ImageButton imageViewCamera;
	static ImageView iv_user_pic;
	static EditText et_signup_firstname;
	static EditText et_signup_lastname;
	static EditText et_signup_username;
	EditText et_signup_password;
	EditText et_signup_repassword;
	EditText et_signup_email;
	// Spinner et_signup_countrycode;

	
	public static AdapterCountrySelect acAdapter;
	static ImageView iv_select_country_flag;
	static TextView tv_select_country_name,tv_select_country_code;
	LinearLayout rl_countrycode;
	
	ArrayList<Country> filterdata;
	ArrayList<Country> globaldata;
	static ArrayList<String> arrValidUserNames; 
	static String strCompleteUName=null;

	static String savedCountryName=null,savedCountryCode=null;
	static Bitmap userPic,countryFlag;
	static String flagInString=null,profilePicInString=null;
	static BitmapDrawable mProfileBitmapDrawable;
	
	
	//Spinner mSpinner;
	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		// TODO Auto-generated method stub
		MenuInflater menuinflater = activity.getMenuInflater();
		inflater.inflate(R.menu.activity_main_actions, menu);

		// Associate searchable configuration with the SearchView
		SearchManager searchManager = (SearchManager) activity.getSystemService(Context.SEARCH_SERVICE);
		SearchView searchView = (SearchView) menu.findItem(R.id.action_search)
				.getActionView();
		searchView.setSearchableInfo(searchManager
				.getSearchableInfo(activity.getComponentName()));
		
		super.onCreateOptionsMenu(menu, inflater);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch (item.getItemId()) {
		case R.id.action_search:
			// search action
			return true;
		case android.R.id.home:
			Log.i("fdf", "dfd");
			getFragmentManager().popBackStack();
		         return true;
		
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	EditText et_signup_cnumber;
	TextView tv_common,tv_setting;
	RelativeLayout backLayout;

	static Fragment mFragement_1;
	static FragmentManager fragmentManager;
	static FragmentTransaction fragmentTransaction;
	static Activity activity;
	static String savedPhoneNumber = null;

	static String isUserNameValid = "";
	static String strUserName=null,strFirstName=null,strEmail=null,strPassword=null;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		
		filterdata=new ArrayList<Country>();
		globaldata=new ArrayList<Country>();
		activity = getActivity();
		fragmentManager = getActivity().getSupportFragmentManager();
		// makeConnection1();
		View view = inflater.inflate(R.layout.fragement_signup, container,
				false);
		
		initialiseHeaderLayout(view);
		rl_countrycode=(LinearLayout)view.findViewById(R.id.rl_countrycode);
		rl_countrycode.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				CustomDialogSelectCountry cdd=new CustomDialogSelectCountry(activity);
				cdd.show(); 
			}
		});
	//	SetData();

		if(!iFirstTime){
			new AsyncPhoneInitTask(getActivity()).execute();
			
		}else{
			System.out.println("on create view calls");		
			iv_select_country_flag.setImageBitmap(stringToBitmap(flagInString));
			//setSavedProfileImage(iv_user_pic, stringToBitmap(profilePicInString));
			if(mProfileBitmapDrawable!=null){
			iv_user_pic.setBackgroundDrawable(mProfileBitmapDrawable);
			imageViewCamera.setImageResource(R.drawable.ic_camera_white);
			}
			tv_select_country_name.setText(savedCountryName);
			tv_select_country_code.setText(savedCountryCode);
		//	iv_user_pic.setImageBitmap(stringToBitmap(profilePicInString));
		}

	
		
		return view;
	}

	/* @Override
	    public void onConfigurationChanged(Configuration newConfig) {
	        super.onConfigurationChanged(newConfig);
	        System.out.println("landscape ");
	       
	        LayoutInflater inflater = LayoutInflater.from(getActivity());
	        populateViewForOrientation(inflater, (ViewGroup) getView());
	       
	    }
	 
	    private void populateViewForOrientation(LayoutInflater inflater, ViewGroup viewGroup) {
	        viewGroup.removeAllViewsInLayout();
	        View subview = inflater.inflate(R.layout.fragement_signup, viewGroup);
	       
	        System.out.println("landscape ");
	        if(mProfileBitmapDrawable!=null){
	        iv_user_pic.setBackgroundDrawable(mProfileBitmapDrawable);
	        }
				iv_select_country_flag.setImageBitmap(stringToBitmap(flagInString));
				//setSavedProfileImage(iv_user_pic, stringToBitmap(profilePicInString));
				iv_user_pic.setBackgroundDrawable(mProfileBitmapDrawable);
				tv_select_country_name.setText(savedCountryName);
				tv_select_country_code.setText(savedCountryCode);
			//	iv_user_pic.setImageBitmap(stringToBitmap(profilePicInString));
			
	 
	        // Find your buttons in subview, set up onclicks, set up callbacks to your parent fragment or activity here.
	        
	        // You can create ViewHolder or separate method for that.
	        // example of accessing views: TextView textViewExample = (TextView) view.findViewById(R.id.text_view_example);
	        // textViewExample.setText("example");
	    }*/
	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		iFirstTime=false;
		super.onCreate(savedInstanceState);
	}

	public static void setFirstTimeVarTrue(){
		iFirstTime=true;
	}
	@Override
	public void onDestroyView() {
		// TODO Auto-generated method stub
	//	iFirstTime=false;
		super.onDestroyView();
	}

	//set first country code
	public void setFirstCountryCodeAndFlag(Country c){
		 //Country c = (Country) mSpinner.getItemAtPosition(position);
		// Country c= (Country)acAdapter.getItem(0);
		    country_code = c.getCountryCodeStr();
		    country_name = c.getName();
		    AlphaCode = c.getCountryISO();
		    PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
		    PhoneNumber phNumberProto = null;
		    // Log.i("phn nmbr  valid() 22 : ", phoneNumber);
		    Locale locale = Locale.getDefault();
		    
		    if(ConnectionDetector.isConnectingToInternet(activity)){

		    Log.i("c_code", country_code);
		    Float input2 = Float.parseFloat(country_code);
		    Integer input1 = Integer.valueOf(input2.intValue());
		    int i_cCode=(int)input1;
		    Log.i("Region Code : ",
		      ""
		        + phoneUtil.getRegionCodeForCountryCode(i_cCode));
		    
		    Log.i("phone number format : ",
		      ""
		        + phoneUtil.getExampleNumber(phoneUtil
		          .getRegionCodeForCountryCode(i_cCode)));
		    
		    PhoneNumber phn = phoneUtil.getExampleNumber(phoneUtil
		      .getRegionCodeForCountryCode(i_cCode));
		    
		    if(phn!=null){
		    int length = country_code.length();
		    Log.i("phn nmbr  format: ",
		      phoneUtil.format(phn, PhoneNumberFormat.INTERNATIONAL));
		    String s = phoneUtil.format(phn,
		      PhoneNumberFormat.INTERNATIONAL);
		    s=s.substring(length, s.length());
		    et_signup_cnumber.setHint(s.trim());
		    System.out.println("COUNTRY CODE-------->>>" + country_code);
		    System.out.println("COUNTRY ALPHACODE-------->>>"
		      + country_name);
		    System.out.println("COUNTRY NAME-------->>>" + AlphaCode);
		    }else{
		    	//for unknown region
		    	 
				    PhoneNumber phn1 = phoneUtil.getExampleNumber(phoneUtil
				      .getRegionCodeForCountryCode(+1));
				    String s = phoneUtil.format(phn1,
						      PhoneNumberFormat.INTERNATIONAL);
				   String tempStr=s.substring(7);
				  	    	
		    	 et_signup_cnumber.setHint(tempStr);
		    }
		    }else{
		    	//Toast.makeText(activity,"No internet connection" ,0).show();
		    }
	}
	public static Bitmap getSmallBitmap(String filePath) {

		File file = new File(filePath);
		long originalSize = file.length();

		final BitmapFactory.Options options = new BitmapFactory.Options();
		options.inJustDecodeBounds = true;
		BitmapFactory.decodeFile(filePath, options);

		// Calculate inSampleSize based on a preset ratio
		options.inSampleSize = calculateInSampleSize(options, 480, 480);

		// Decode bitmap with inSampleSize set
		options.inJustDecodeBounds = false;

		Bitmap compressedImage = BitmapFactory.decodeFile(filePath, options);

		return compressedImage;
	}

	public static int calculateInSampleSize(BitmapFactory.Options options,
			int reqWidth, int reqHeight) {
		final int height = options.outHeight;
		final int width = options.outWidth;
		int inSampleSize = 1;

		if (height > reqHeight || width > reqWidth) {
			final int heightRatio = Math.round((float) height
					/ (float) reqHeight);
			final int widthRatio = Math.round((float) width / (float) reqWidth);
			inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;
		}
		final float totalPixels = width * height;
		final float totalReqPixelsCap = reqWidth * reqHeight * 2;
		while (totalPixels / (inSampleSize * inSampleSize) > totalReqPixelsCap) {
			inSampleSize++;
		}

		return inSampleSize;
	}

	// initialize all UI fields on screen
	private void initialiseHeaderLayout(View view) {
		mAdapter = new com.iamxam.adapter.CountryAdapter(getActivity());
		ImageView iv_header_back = (ImageView) view.findViewById(R.id.iv_back);
		iv_header_back.setOnClickListener(this);
		ImageView iv_top_logo = (ImageView) view.findViewById(R.id.iv_top_logo);
		iv_top_logo.setOnClickListener(this);

		backLayout=(RelativeLayout)view.findViewById(R.id.backLayout);
		backLayout.setOnClickListener(this);
		tv_setting = (TextView) view.findViewById(R.id.tv_header_back_text);
		tv_setting.setOnClickListener(this);
		tv_setting.setText("Sign Up");
		tv_setting.setVisibility(View.INVISIBLE);

		tv_common = (TextView) view.findViewById(R.id.tv_common);
		tv_common.setOnClickListener(this);

		imageViewCamera = (ImageButton) view.findViewById(R.id.imageViewCamera);
		imageViewCamera.setOnClickListener(this);
		iv_user_pic = (ImageView) view.findViewById(R.id.iv_user_pic);
		iv_user_pic.setOnClickListener(this);

		et_signup_firstname = (EditText) view
				.findViewById(R.id.et_signup_firstname);
		

		et_signup_lastname = (EditText) view
				.findViewById(R.id.et_signup_lastname);
		et_signup_lastname.setOnFocusChangeListener(this);

		et_signup_username = (EditText) view
				.findViewById(R.id.et_signup_username);
		et_signup_username.setOnFocusChangeListener(this);

		et_signup_password = (EditText) view
				.findViewById(R.id.et_signup_password);
		et_signup_password.setOnFocusChangeListener(this);

		et_signup_repassword = (EditText) view
				.findViewById(R.id.et_signup_repassword);
		et_signup_repassword.setOnFocusChangeListener(this);

		et_signup_email = (EditText) view.findViewById(R.id.et_signup_email);
		et_signup_email.setOnFocusChangeListener(this);
		et_signup_email.setText(UserEmailFetcher.getEmail(activity));

				et_signup_cnumber = (EditText) view
				.findViewById(R.id.et_signup_cnumber);
		
		et_signup_cnumber.setOnFocusChangeListener(this);
		
		iv_select_country_flag=(ImageView)view.findViewById(R.id.iv_select_country_flag);
		tv_select_country_name=(TextView)view.findViewById(R.id.tv_select_country_name);
		tv_select_country_code=(TextView)view.findViewById(R.id.tv_select_country_code1);

	}

	

	@Override
	public void onClick(View v) {

		switch (v.getId()) {
		
		case R.id.backLayout:

			// fragmentManager =activity.getFragmentManager();
			iFirstTime=false;
			startActivity(new Intent(getActivity(), LandingActivity.class));
			getActivity().finish();
			break;
		case R.id.iv_back:

			// fragmentManager =activity.getFragmentManager();
			iFirstTime=false;
			startActivity(new Intent(getActivity(), LandingActivity.class));
			getActivity().finish();
			break;
		case R.id.iv_top_logo:
			iFirstTime=false;
			startActivity(new Intent(getActivity(), LandingActivity.class));
			getActivity().finish();
			break;

		case R.id.tv_common:
			boolean isfieldEmpty = checkForEmpty();
			if (isfieldEmpty) {
				if (checkPattern()) {
					 strUserName = et_signup_username.getText()
							.toString().trim();
					 strFirstName = et_signup_firstname.getText()
							.toString().trim();
					 strEmail = et_signup_email.getText().toString()
							.trim();
					strPassword=et_signup_password.getText().toString().trim();
					 
					String strRequestPattern = "{\"type\":\"reg\",\"user\":\""
							+ strUserName + "\",\"name\":\"" + strFirstName
							+ "\",\"email\":\"" + strEmail
							+ "\",\"id\":\"msgid\"}";
					System.out.println("pattern : "+strRequestPattern);
					// must be uncomment
					if (!strUserName.equals(isUserNameValid)) {
						if(ConnectionDetector.isConnectingToInternet(activity)){
						WebSocketHelper.sendRequest(strRequestPattern,
								Appconstants.CLASS_SIGNUP_HELPER);
						}else{
							Toast.makeText(activity,"No internet connection" ,0).show();
						}
					//	goNext();
					} else {
						et_signup_username
								.setError("Username has already been taken");
					}
				}

			}
			

			break;
		case R.id.imageViewCamera:
			/*final AlertDialog dialog = builder.create();
			dialog.show();*/
			picChooser();
			break;

		case R.id.iv_user_pic:
			/*final AlertDialog dialog1 = builder.create();
			dialog1.show();*/
		picChooser();
			break;

		default:
			break;
		}
	}

	//pic intent for default dialog camera & gallery same time
	public void  picChooser(){
		// callGallery();
		Intent intent = new Intent();

		intent.setType("image/*");
		intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
		
		 Intent chooser = Intent.createChooser(intent,"Choose profile picture");
		
		 Intent intent1 = new Intent(
					android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
			
			/**
			 * Also specify the Uri to save the image on specified path
			 * and file name. Note that this Uri variable also used by
			 * gallery app to hold the selected image path.
			 */
			mImageCaptureUri = Uri.fromFile(new File(Environment
					.getExternalStorageDirectory(), "tmp_avatar_"
					+ String.valueOf(System.currentTimeMillis())
					+ ".jpg"));

			intent1.putExtra(android.provider.MediaStore.EXTRA_OUTPUT,
					mImageCaptureUri);					

			
			 //chooser = Intent.createChooser(intent1,"Choose profile picture");
                Intent[] extraIntents = {intent1};

                //Intent[] extraIntents = {cameraIntent};
                chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, extraIntents);
			
		startActivityForResult(chooser, IMAGE_PICK);
	}
	// enable/disable top "Next button"
	public void checkForNextButton() {
		if (!checkPattern()) {
			if (!checkForEmpty()) {
				/*
				 * tv_common.setTextColor(Color.parseColor("#BCC6CC"));
				 * tv_common.setEnabled(false);
				 */
			}
		} else {
			// tv_common.setTextColor(android.R.color.black);
			/*
			 * tv_common.setEnabled(true);
			 * tv_common.setTextColor(activity.getResources
			 * ().getColor(R.color.c_top_blue));
			 */
		}
	}

	// on focus change listener of edit texts
	@Override
	public void onFocusChange(View v, boolean hasFocus) {
		// TODO Auto-generated method stub
		boolean isValid = true;
		boolean checkValid = false;
		if (hasFocus) {
			switch (v.getId()) {
			case R.id.et_signup_lastname:
				Log.i("done", "first name");
				checkValid = ((et_signup_firstname.getText().toString().trim()
						.length() > 0));
				if (!checkValid) {
					et_signup_firstname.setError("Enter a valid First Name");
					isValid = false;
				} else {
					if (!(et_signup_firstname.getText().toString().trim())
							.matches(Appconstants.PATTERN_NAME)) {
						et_signup_firstname
								.setError("No special characters allowed");
					}
				}

				et_signup_firstname.setText(WordUtils
						.capitalizeFully(et_signup_firstname.getText()
								.toString().trim()));
				break;

			case R.id.et_signup_username:
				checkValid = (et_signup_lastname.getText().toString().trim())
						.length() > 0;
				if (!checkValid) {
					et_signup_lastname.setError("Enter a valid Last Name");
					isValid = false;
				} else {
					if (!(et_signup_lastname.getText().toString().trim())
							.matches(Appconstants.PATTERN_NAME)) {
						et_signup_lastname
								.setError("No special characters allowed");
					}else{
						
						String strFName = et_signup_firstname.getText()
								.toString().trim().replace(" ", "");
						String strLName=et_signup_lastname.getText()
								.toString().trim().replace(" ", "");						
					
						arrValidUserNames=new ArrayList<String>();
						//int i=0;
														
								final String strRequestPattern = "{\"type\":\"newaccnt\",\"fn\":\""
										+ strFName + "\",\"ln\":\""
										+ strLName + "\",\"id\":\"msgid\"}";
								
								if(ConnectionDetector.isConnectingToInternet(activity)){
									WebSocketHelper.sendRequest(strRequestPattern,
											Appconstants.CLASS_SIGNUP_HELPER);
								}else{
										Toast.makeText(activity,"No internet connection" ,0).show();
									}
					
						
					}
				}
				et_signup_lastname.setText(WordUtils
						.capitalizeFully(et_signup_lastname.getText()
								.toString().trim()));

				break;

			case R.id.et_signup_password:
				checkValid = (et_signup_username.getText().toString().trim())
						.length() > 0;
				if (!checkValid) {
					et_signup_username.setError("Enter a valid User Name");
					isValid = false;
				} else {
					if (!(et_signup_username.getText().toString().trim())
							.matches(Appconstants.PATTERN_USERNAME)) {
						et_signup_username
								.setError("No special characters allowed except for underscore ( _ )");
					} else {
						String strUname = et_signup_username.getText()
								.toString().trim();
						String strRequestPattern = "{\"type\":\"user_exists\",\"user\":\""
								+ strUname + "\",\"id\":\"msgid\"}";
						// must be uncomment
						if(ConnectionDetector.isConnectingToInternet(activity)){
						WebSocketHelper.sendRequest(strRequestPattern,
								Appconstants.CLASS_SIGNUP_HELPER);
						}else{
							Toast.makeText(activity,"No internet connection" ,0).show();
						}
					}
				}
				break;

			case R.id.et_signup_repassword:
				checkValid = (et_signup_password.getText().toString().trim())
						.length() > 0;
				if (!checkValid) {
					et_signup_password.setError("Enter a valid Password");
					isValid = false;
				} else {
					if (!(et_signup_password.getText().toString().trim()
							.length() >= 6)) {
						et_signup_password
								.setError("Enter 6 or more characters");
					}
				}
				break;

			case R.id.et_signup_email:
				checkValid = et_signup_repassword.getText().toString().trim()
						.length() > 0;
				if (!checkValid) {
					et_signup_repassword
							.setError("Enter a valid Verify Password");
					isValid = false;
				} else {
					if (!(et_signup_repassword.getText().toString().trim())
							.equals(et_signup_password.getText().toString()
									.trim())) {
						et_signup_repassword.setError("Passwords must match");
					}
				}
				break;

			case R.id.et_signup_cnumber:
				checkValid = et_signup_email.getText().toString().trim()
						.length() > 0;
				if (!checkValid) {
					et_signup_email.setError("Enter a valid email");
					isValid = false;
				} else {
					if (!isEmailValid(et_signup_email.getText().toString()
							.trim())) {
						et_signup_email.setError("Enter a valid email");
					}
				}
				break;

			default:
				break;
			}
		}

	}

	// go to next fragment
	public static void goNext() {
		
		mFragement_1 = new LoginVerificationHelper();		
		fragmentTransaction = fragmentManager.beginTransaction();
		fragmentTransaction.replace(android.R.id.content, mFragement_1);
		fragmentTransaction.addToBackStack("signup1");
		fragmentTransaction.commit();		
		LoginVerificationHelper.setInputParameters(strUserName, strFirstName, strEmail, strPassword);

	}

	// call from "WebSocketHelper" class when receive response from web socket
	public static void doAction(JSONObject jo) {
		try {
			int strResponse = jo.getInt("code");
			Log.i("response code is : ", "" + strResponse);
			switch (strResponse) {
			case 0:
				JSONArray arrSuggestions=jo.getJSONArray("ss");
				for(int i=0;i<arrSuggestions.length();i++){
					arrValidUserNames.add(arrSuggestions.getString(i));
				}
				showUserNameSuggestionDropDown(et_signup_username);
				break;
			
			case 2:
				goNext();
				break;
			case 8:
				isUserNameValid = et_signup_username.getText().toString()
						.trim();
				et_signup_username.setError("Username has already been taken");
				break;
			case 9:
				isUserNameValid = "";
				break;
			case 58:
				Toast.makeText(activity,
						Appconstants.hmErrorCodes.get(strResponse), 0).show();
				break;

			default:
				break;
			}
		
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	//drop down pop window for username suggestions
	public static void showUserNameSuggestionDropDown(View anchor) {
		final ListPopupWindow lpw = new ListPopupWindow(activity);
		ArrayAdapter<String> pa = new ArrayAdapter<String>(activity,
				R.layout.custom_drop_down,arrValidUserNames);
		lpw.setAdapter(pa);
		// setting up an anchor view
		lpw.setAnchorView(anchor);
		// Setting measure specifications. I'v used this mesure specs to display
		// my
		// ListView as wide as my anchor view is
		lpw.setHeight(android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
		lpw.setWidth(anchor.getWidth());
		
		
		// Background is needed. You can use your own drawable or make a 9patch.
		// I'v used a custom btn drawable. looks nice.
		lpw.setBackgroundDrawable(activity.getResources().getDrawable(
				android.R.drawable.alert_light_frame));
		// Offset between anchor view and popupWindow
		lpw.setVerticalOffset(-10);
		lpw.setHorizontalOffset(0);

		lpw.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// / Our action.....
				
				et_signup_username.setText(((TextView) arg1).getText().toString());
				lpw.dismiss();
			}
		});
		lpw.show();
	}
	
	

	// chooser for profile pic either from camera or gallery
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		
		if (resultCode == Activity.RESULT_OK) {
			switch (requestCode) {
			case IMAGE_PICK:	
				if(data !=null){
				mImageCaptureUri = data.getData();}				
				doCrop();
				break;
			
			case CROP_FROM_CAMERA:
				Bundle extras = data.getExtras();
				/**
				 * After cropping the image, get the bitmap of the cropped image and
				 * display it on imageview.
				 */

				
				if (extras != null) {
					srcBitmap = extras.getParcelable("data");					
					//iv_user_pic.setImageBitmap(srcBitmap);
					updateImageView(srcBitmap);
				}
				break;
			default:
				break;
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	//crop selected or captured image
	private void doCrop() {
		  final ArrayList<CropOption> cropOptions = new ArrayList<CropOption>();
		  /**
		   * Open image crop app by starting an intent
		   * �com.android.camera.action.CROP�.
		   */
		  Intent intent = new Intent("com.android.camera.action.CROP");
		  intent.setType("image/*");
		  //intent.setDataAndType(mImageCaptureUri, "image/*");
		  /**
		   * Check if there is image cropper app installed.
		   */
		  List<ResolveInfo> list = getActivity().getPackageManager().queryIntentActivities(
		    intent, 0);

		  int size = list.size();
		  
		  /**
		   * If there is no image cropper app, display warning message
		   */
		  
		  if (size == 0) {
		   Toast.makeText(getActivity(), "Can not find image crop app",
		     Toast.LENGTH_SHORT).show();
		   return;
		  } else {
		   /**
		    * Specify the image path, crop dimension and scale
		    */
		   intent.setData(mImageCaptureUri);
		   //intent.setDataAndType(mImageCaptureUri, "image/*");
		   intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
		       //set crop properties
		   intent.putExtra("crop", "true");
		   intent.putExtra("outputX", 200);
		   intent.putExtra("outputY", 200);
		   intent.putExtra("aspectX", 1);
		   intent.putExtra("aspectY", 1);
		   intent.putExtra("scale", true);
		   intent.putExtra("return-data", true);
		   /**
		    * There is posibility when more than one image cropper app exist,
		    * so we have to check for it first. If there is only one app, open
		    * then app.
		    */
		   if (size == 1) {
		    Intent i = new Intent(intent);
		    ResolveInfo res = list.get(0);

		    i.setComponent(new ComponentName(res.activityInfo.packageName,
		      res.activityInfo.name));
		    startActivityForResult(i, CROP_FROM_CAMERA);
		   } else {
		    /**
		     * If there are several app exist, create a custom chooser to
		     * let user selects the app.
		     */
		    
		    
		    for (ResolveInfo res : list) {
		     final CropOption co = new CropOption();

		     co.appIntent = new Intent(intent);
		     co.appIntent
		       .setComponent(new ComponentName(
		         res.activityInfo.packageName,
		         res.activityInfo.name));
		     cropOptions.add(co);
		    }

		    startActivityForResult(
		      cropOptions.get(0).appIntent,
		      CROP_FROM_CAMERA);

		   }
		  }
		 }
	
	// set bitmap image on image view
	@SuppressWarnings("deprecation")
	private void updateImageView(Bitmap newImage) {
	
		RoundedTransformation round = new RoundedTransformation(8, 0);
		Bitmap bmp = round.transform(newImage);
		
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		bmp.compress(Bitmap.CompressFormat.PNG, 10, out);
		Bitmap decoded = BitmapFactory.decodeStream(new ByteArrayInputStream(
				out.toByteArray()));

		System.out.println("Bitmap rounded---------------->" + bmp);

		BitmapDrawable mBitamp = new BitmapDrawable(getResources(), decoded);
	
		mProfileBitmapDrawable=mBitamp;
		imageViewCamera.setImageResource(R.drawable.ic_camera_white);
		Signuphelper.iv_user_pic.setBackgroundDrawable(mBitamp);
	}
	

	public class RoundedTransformation implements
			com.squareup.picasso.Transformation {
		private final int radius;
		private final int margin; // dp

		// radius is corner radii in dp
		// margin is the board in dp
		public RoundedTransformation(final int radius, final int margin) {
			this.radius = radius;
			this.margin = margin;
		}

		@Override
		public Bitmap transform(final Bitmap source) {
			final Paint paint = new Paint();
			paint.setAntiAlias(true);
			paint.setShader(new BitmapShader(source, Shader.TileMode.CLAMP,
					Shader.TileMode.CLAMP));

			Bitmap output = Bitmap.createBitmap(source.getWidth(),
					source.getHeight(), Config.ARGB_8888);
			Canvas canvas = new Canvas(output);
			canvas.drawRoundRect(new RectF(margin, margin, source.getWidth()
					- margin, source.getHeight() - margin), radius, radius,
					paint);

			if (source != output) {
				source.recycle();
			}

			return output;
		}

		@Override
		public String key() {
			return "rounded";
		}
	}


	// check email validation
	public static boolean isEmailValid(String email) {
		boolean isValid = false;

		String expression = Appconstants.PATTERN_EMAIL;
		CharSequence inputStr = email;

		Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(inputStr);
		if (matcher.matches()) {
			isValid = true;
		}
		return isValid;
	}

	// check any of edit text empty
	private boolean checkForEmpty() {
		boolean isValid = true;
		boolean checkValid = false;

		checkValid = (et_signup_cnumber.getText().toString().trim()).length() > 0;
		;
		if (!checkValid) {
			et_signup_cnumber.setError("Enter a valid Phone Number");
			et_signup_cnumber.requestFocus();
			isValid = false;
		}
		checkValid = (et_signup_email.getText().toString().trim()).length() > 0;
		;
		if (!checkValid) {
			et_signup_email.setError("Enter a valid Email");
			et_signup_email.requestFocus();
			isValid = false;
		}
		checkValid = (et_signup_repassword.getText().toString().trim())
				.length() > 0;
		if (!checkValid) {
			et_signup_repassword.setError("Enter a valid Verify Password");
			et_signup_repassword.requestFocus();
			isValid = false;
		}
		checkValid = (et_signup_password.getText().toString().trim()).length() > 0;
		if (!checkValid) {
			et_signup_password.setError("Enter a valid Password");
			et_signup_password.requestFocus();
			isValid = false;
		}
		checkValid = (et_signup_username.getText().toString().trim()).length() > 0;
		if (!checkValid) {
			et_signup_username.setError("Enter a valid User Name");
			et_signup_username.requestFocus();
			isValid = false;
		}
		checkValid = (et_signup_lastname.getText().toString().trim()).length() > 0;
		if (!checkValid) {
			et_signup_lastname.setError("Enter a valid Last Name");
			et_signup_lastname.requestFocus();
			isValid = false;
		}
		
		checkValid = (et_signup_firstname.getText().toString().trim()).length() > 0;
		if (!checkValid) {
			et_signup_firstname.setError("Enter a valid First Name");
			et_signup_firstname.requestFocus();
			isValid = false;
		}

		return isValid;
	}

	// check for pattern matching of edit texts
	private boolean checkPattern() {
		boolean isValid = true;
		boolean checkValid = false;

		// first name
		checkValid = ((et_signup_firstname.getText().toString().trim())
				.matches(Appconstants.PATTERN_NAME));
		if (!checkValid) {
			et_signup_firstname.setError("No special characters allowed");
			isValid = false;
		} else {
		}

		et_signup_firstname.setText(WordUtils
				.capitalizeFully(et_signup_firstname.getText().toString()
						.trim()));

		// last name
		checkValid = (et_signup_lastname.getText().toString().trim())
				.matches(Appconstants.PATTERN_NAME);
		if (!checkValid) {
			et_signup_lastname.setError("No special characters allowed");
			isValid = false;
		} else {
		}
		et_signup_lastname.setText(WordUtils.capitalizeFully(et_signup_lastname
				.getText().toString().trim()));

		// username
		checkValid = (et_signup_username.getText().toString().trim())
				.matches(Appconstants.PATTERN_USERNAME);
		if (!checkValid) {
			et_signup_username
					.setError("No special characters allowed except for underscore ( _ )");
			isValid = false;
		} else {
		}

		// password
		checkValid = (et_signup_password.getText().toString().trim()).length() >= 6;
		if (!checkValid) {
			et_signup_password.setError("Enter 6 or more characters");
			isValid = false;
		} else {
		}

		// repassword
		checkValid = (et_signup_repassword.getText().toString().trim())
				.equals(et_signup_password.getText().toString().trim());
		if (!checkValid) {
			et_signup_repassword.setError("Passwords must match");
			isValid = false;
		} else {
		}

		// email
		checkValid = isEmailValid(et_signup_email.getText().toString().trim());
		if (!checkValid) {
			et_signup_email.setError("Enter a valid email");
			isValid = false;
		} else {
		}

		// phone number
		String phone = et_signup_cnumber.getText().toString().trim();
		/*if (!phone.startsWith("+")) {
			et_signup_cnumber.setText("+" + country_code + phone);
		}*/
		checkValid = (phone.length() > 0) && isPhoneValid();
		if (!checkValid) {
			et_signup_cnumber
					.setError("Enter a valid phone number. Phone number does not match country code selected");
			isValid = false;
		} else {
			 if(ConnectionDetector.isConnectingToInternet(activity)){
				 
			 }else{
				 isValid = false;
				 Toast.makeText(activity,"No internet connection" ,0).show();
			 }

		}

	return isValid;
	}

	
	// check phone number is valid or not
	private boolean isPhoneValid() {
		// TODO Auto-generated method stub

		String phoneNumber = null;
		String phone = et_signup_cnumber.getText().toString().trim();
		/*if (phone.startsWith("+")) {
			phone = phone.substring(country_code.length() + 1, phone.length());
		}*/
		phoneNumber = country_code + phone;

		Log.i("phn nmbr  valid() 11 : ", phoneNumber);

		if (phoneNumber.length() == 7) {
			phoneNumber = "02" + phoneNumber;
		}
		PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
		PhoneNumber phNumberProto = null;
		
		try {
			Log.i("phn nmbr  valid() 22 : ", phoneNumber);
			phNumberProto = phoneUtil.parse(phoneNumber, country_code);
			
			
		} catch (NumberParseException e) {
			// if there's any error
			System.err.println("NumberParseException was thrown: "
					+ e.toString());
		}

		// check if the number is valid
		boolean isPhoneValids = phoneUtil.isValidNumber(phNumberProto);
		String ss=PhoneNumberUtils.formatNumber(phoneNumber);
		Log.i("nnnnn", ss);
		if (isPhoneValids) {

			// get the valid number's international format
			String internationalFormat = phoneUtil.format(phNumberProto,
					PhoneNumberFormat.INTERNATIONAL);

			/*
			 * Toast.makeText( getActivity(), "Phone number VALID: " +
			 * internationalFormat, Toast.LENGTH_SHORT).show();
			 */

			phoneNumber = "";

		} else {

			// prompt the user when the number is invalid
			/*
			 * Toast.makeText( getActivity(), "Phone number is INVALID: " +
			 * phoneNumber, Toast.LENGTH_SHORT).show();
			 */
			phoneNumber = "";

		}

		return isPhoneValids;
	}

	
	// adapter for country codes
	public class CustomAlertAdapter extends BaseAdapter {
		ArrayList<BeanCountryCode> al_contry;
		Context ctx = null;

		private LayoutInflater mInflater = null;

		public CustomAlertAdapter(Activity activty,
				ArrayList<BeanCountryCode> al_contry) {
			this.ctx = activty;
			mInflater = activty.getLayoutInflater();
			this.al_contry = al_contry;

		}

		@Override
		public int getCount() {

			return al_contry.size();
		}

		@Override
		public Object getItem(int arg0) {
			return null;
		}

		@Override
		public long getItemId(int arg0) {
			return 0;
		}

		@Override
		public View getView(final int position, View convertView, ViewGroup arg2) {
			final ViewHolder holder;
			if (convertView == null) {
				holder = new ViewHolder();
				convertView = mInflater.inflate(R.layout.dialog_custom, null);

				holder.titlename = (TextView) convertView
						.findViewById(R.id.txt);
				/*
				 * holder.Cntry_code = (TextView) convertView
				 * .findViewById(R.id.txt_code);
				 */
				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}

			country_name = al_contry.get(position).getCountry();

			country_code = al_contry.get(position).getCountry_code();
			AlphaCode = al_contry.get(position).getAlphaCode();
			holder.titlename.setText(country_name + "  " + country_code);
			// holder.Cntry_code.setText(CountryCode);

			convertView.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					country_name = al_contry.get(position).getCountry();
					country_code = al_contry.get(position).getCountry_code();
					AlphaCode = al_contry.get(position).getAlphaCode();

					// ggggg
					// et_signup_countrycode.setText(CountryName+"("+CountryCode+")");
					dialogCountry.dismiss();
				}
			});

			return convertView;
		}

		private class ViewHolder {
			TextView titlename;
			TextView Cntry_code;
		}
	}



	protected class AsyncPhoneInitTask extends
			AsyncTask<Void, Void, ArrayList<Country>> {

		private int mSpinnerPosition = -1;
		private Context mContext;
		String objCountry;
		public AsyncPhoneInitTask(Context context) {
			mContext = context;
		}

		@Override
		protected ArrayList<Country> doInBackground(Void... params) {
			ArrayList<Country> data = new ArrayList<Country>(233);
			BufferedReader reader = null;
			try {
				reader = new BufferedReader(new InputStreamReader(mContext
						.getApplicationContext().getAssets()
						.open("countries.dat"), "UTF-8"));

				// do reading, usually loop until end of file reading
				String line;
				int i = 0;
				while ((line = reader.readLine()) != null) {
					// process line
					Country c = new Country(mContext, line, i);
					data.add(c);
					
					ArrayList<Country> list = mCountriesMap.get(c
							.getCountryCode());
					if (list == null) {
						list = new ArrayList<Country>();
						mCountriesMap.put(c.getCountryCode(), list);
					}
					list.add(c);
					i++;
				}
			} catch (IOException e) {
				// log the exception
			} finally {
				if (reader != null) {
					try {
						reader.close();
					} catch (IOException e) {
						// log the exception
					}
				}
			}
			
			return data;
		}

		@Override
		protected void onPostExecute(ArrayList<Country> data) {
			/*mAdapter.addAll(data);
			if (mSpinnerPosition > 0) {
				//mSpinner.setSelection(mSpinnerPosition);
			}*/
			//acAdapter.addAll(data);
			Country cc=data.get(0);
			
			
			globaldata=data;
			acAdapter=new AdapterCountrySelect(activity,data);
			
			
			
			tv_select_country_name.setText(cc.getName());
			tv_select_country_code.setText(cc.getCountryCodeStr());
			setFirstCountryCodeAndFlag(cc);
			iFirstTime=true;
		
		}

	}
	
	public class CropOptionAdapter extends ArrayAdapter<CropOption> {
		private ArrayList<CropOption> mOptions;
		private LayoutInflater mInflater;

		public CropOptionAdapter(Context context, ArrayList<CropOption> options) {
			super(context, R.layout.crop_selector, options);
			mOptions = options;
			mInflater = LayoutInflater.from(context);
		}
		
		@Override
		public View getView(int position, View convertView, ViewGroup group) {
			if (convertView == null)
				convertView = mInflater.inflate(R.layout.crop_selector, null);

				CropOption item = mOptions.get(position);

				if (item != null) {
					((ImageView) convertView.findViewById(R.id.iv_icon))
						.setImageDrawable(item.icon);
					((TextView) convertView.findViewById(R.id.tv_name))
						.setText(item.title);
					return convertView;
				}
			return null;
		}
	}
	
	
	public class CropOption {
		public CharSequence title;
		public Drawable icon;
		public Intent appIntent;
	}

	@Override
	public boolean onNavigationItemSelected(int itemPosition, long itemId) {
		// TODO Auto-generated method stub
		return false;
	}

	//Country select dialog class
		public class CustomDialogSelectCountry extends Dialog implements
	    android.view.View.OnClickListener {

	  public Activity c;
	  public Dialog d;
	  public Button bt_cancel_dialog;
	  public EditText et_country_search;
	  public ListView lv_countries_with_flag;

	  public CustomDialogSelectCountry(Activity a) {
	    super(a);
	    // TODO Auto-generated constructor stub
	    this.c = a;
	  }

	  @Override
	  protected void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    requestWindowFeature(Window.FEATURE_NO_TITLE);
	    setContentView(R.layout.dialog_select_country);
	    bt_cancel_dialog = (Button) findViewById(R.id.bt_cancel_dialog);  
	    bt_cancel_dialog.setOnClickListener(this);
	    et_country_search=(EditText)findViewById(R.id.et_country_search);
	    et_country_search.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub
				String searchString=s.toString();
				
				
				
				
				filterdata.clear();
			     if (globaldata.size() > 0 && searchString.length() > 0) {
			      for (Country bean : globaldata) {
			       if (bean.getName()
			         .toLowerCase()
			         .contains(
			           searchString.toString()
			             .toLowerCase())) {
			    	   filterdata.add(bean);
			       }
			      }
			      
			      AdapterCountrySelect  cAdapter=new AdapterCountrySelect(activity,filterdata);
					cAdapter.notifyDataSetChanged();
					
					lv_countries_with_flag.setAdapter(cAdapter);
			
			      
			     }else{
			    	 filterdata.clear();
			    	 
			    	 AdapterCountrySelect  cAdapter=new AdapterCountrySelect(activity,globaldata);
						cAdapter.notifyDataSetChanged();
						
						lv_countries_with_flag.setAdapter(cAdapter);
			     }

			}
		});
	    
	    
	    lv_countries_with_flag=(ListView)findViewById(R.id.lv_countries_with_flag);
	    System.out.println("size  ; "+globaldata.size());
	    AdapterCountrySelect  cAdapter=new AdapterCountrySelect(activity,globaldata);
		cAdapter.notifyDataSetChanged();
		lv_countries_with_flag.setAdapter(cAdapter);

	    
	    lv_countries_with_flag.setOnItemClickListener(new AdapterView.OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position,
					long id) {
				// TODO Auto-generated method stub
				Object o=lv_countries_with_flag.getItemAtPosition(position);
				 Country c = (Country)o;
				 iv_select_country_flag.setImageResource(c.getResId());
				 tv_select_country_name.setText(c.getName());				
				 tv_select_country_code.setText(c.getCountryCodeStr());				
				 setFirstCountryCodeAndFlag(c);
				 
				 savedCountryName=tv_select_country_name.getText().toString().trim();
					savedCountryCode=tv_select_country_code.getText().toString().trim();
					countryFlag=((BitmapDrawable)iv_select_country_flag.getDrawable()).getBitmap();
					flagInString=bitmapToString(countryFlag);
				 
				 dismiss();
			}
		});
	  

	  }

	  @Override
	  public void onClick(View v) {
	    switch (v.getId()) {
	    case R.id.bt_cancel_dialog:
	    	this.dismiss();
	      break;
	   
	    default:
	      break;
	    }
	    dismiss();
	  }
	}

		
// convert image to string
		public static String bitmapToString(Bitmap image) {
		    Bitmap immage = image;
		    ByteArrayOutputStream baos = new ByteArrayOutputStream();
		    immage.compress(Bitmap.CompressFormat.PNG, 100, baos);
		    byte[] b = baos.toByteArray();
		    String imageEncoded = Base64.encodeToString(b, Base64.DEFAULT);

		    Log.d("Image Log:", imageEncoded);
		    return imageEncoded;
		}
		
		public static String profilebitmapToString(Bitmap image) {
		    Bitmap immage = image;
		    ByteArrayOutputStream baos = new ByteArrayOutputStream();
		    byte[] b = baos.toByteArray();
		    String imageEncoded = Base64.encodeToString(b, Base64.DEFAULT);

		    Log.d("Image Log:", imageEncoded);
		    return imageEncoded;
		}
//convert string to bitmap image
		 public static Bitmap stringToBitmap(String input) {
		        byte[] decodedByte = Base64.decode(input, 0);
		        return BitmapFactory
		                .decodeByteArray(decodedByte, 0, decodedByte.length);
		    }
		
}
