package com.iamxam.fragments;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.iamxam.R;
import com.iamxam.apputils.AppUtils;

public class ManageQviteSettingFragment extends Fragment implements OnClickListener{

	private Fragment mFragement;
	private TextView tv_setting;
	private ListView mChatListView;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_setting_qvitee_vote, container, false);
		initialiseLayoutVariables(view);
		initiliaseHeaderLayout(view);
		return view;
	}


	private void initialiseLayoutVariables(View view) {

		mChatListView = (ListView) view.findViewById(R.id.lv_manage_qvite_vote);
		List<String> list = new ArrayList<String>();
		list.add("Aleks");
		list.add("amanda");
		list.add("Aleks");
		list.add("amanda");
		list.add("Aleks");
		list.add("amanda");
		list.add("Aleks");
		list.add("amanda");
		list.add("Aleks");
		list.add("amanda");
		list.add("Aleks");
		list.add("amanda");
		list.add("Aleks");
		list.add("amanda");
		list.add("Aleks");
		list.add("amanda");
		list.add("Aleks");
		list.add("amanda");
		list.add("Aleks");
		list.add("amanda");
		list.add("Aleks");
		list.add("amanda");
		list.add("Aleks");
		list.add("amanda");
		

		UserAdapter mUserAdapter = new UserAdapter(getActivity(), list);
		mChatListView.setAdapter(mUserAdapter);

	}

	private void initiliaseHeaderLayout(View view) {

		view.findViewById(R.id.iv_back).setOnClickListener(this);

		tv_setting = (TextView) view.findViewById(R.id.tv_header_back_text);
		tv_setting.setOnClickListener(this);
		tv_setting.setVisibility(View.VISIBLE);

		view.findViewById(R.id.tv_common).setVisibility(View.INVISIBLE);

		TextView tv_header = (TextView) view.findViewById(R.id.tv_header);
		tv_header.setText(R.string.txt_setting_qvites);
	}

	@Override
	public void onClick(View v) {

		switch (v.getId()) {
		case R.id.iv_back:
			tv_setting.setVisibility(View.GONE);		
			AppUtils.startSettingTab(getActivity());			
			break;

		case R.id.tv_header_back_text:			
			AppUtils.startSettingTab(getActivity());
		default:
			break;
		}
	}


	private void changeFragmentView() {


		mFragement = new SettingFragement();
		FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
		FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
		fragmentTransaction.replace(android.R.id.content, mFragement);
		fragmentTransaction.commit();
	}


	public class UserAdapter extends BaseAdapter{

		Activity act;
		List<String> list;
		public UserAdapter(Activity act, List<String> list){
			this.act = act;
			this.list = list;
		}

		@Override
		public int getCount() {
			return list.size();
		}

		@Override
		public Object getItem(int position) {
			return position;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {

			if (convertView == null) {
				convertView = LayoutInflater.from(act).inflate(R.layout.row_mangae_qvite_vote_setting, parent, false);
			}

			TextView tvName = (TextView) convertView.findViewById(R.id.tv_chat_row_nick_name);
			tvName.setText(list.get(position));
			return convertView;
		}

	}

}
