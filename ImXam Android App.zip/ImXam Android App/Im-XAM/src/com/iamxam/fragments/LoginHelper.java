package com.iamxam.fragments;

import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.iamxam.R;
import com.iamxam.activity.LandingActivity;
import com.iamxam.activity.MainActivity;
import com.iamxam.appconstant.Appconstants;
import com.iamxam.internet.ConnectionDetector;
import com.iamxam.websockethelper.WebSocketHelper;

@SuppressLint("NewApi")
public class LoginHelper extends Fragment implements OnClickListener{
	static Fragment mFragement;
	static  FragmentManager fragmentManager;
	static FragmentTransaction fragmentTransaction;
	static Activity activity;
	static LoginHelper objLoginHelper;
	
	TextView tv_setting;
	EditText et_login_username,et_login_password;
	RelativeLayout backLayout;
	
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		activity=getActivity();
		objLoginHelper=new LoginHelper();
		
		View view = inflater.inflate(R.layout.fragment_login, container, false);
		initiliseHeaderLayout(view);
		initialiseLayoutVariables(view);
		return view;
	}

	private void initialiseLayoutVariables(View view) {

		view.findViewById(R.id.tv_forgot_pass).setOnClickListener(this);
	}

	private void initiliseHeaderLayout(View view) {
		ImageView iv_header_back = (ImageView) view.findViewById(R.id.iv_back);
		iv_header_back.setOnClickListener(this);
		ImageView iv_top_logo = (ImageView) view.findViewById(R.id.iv_top_logo);
		iv_top_logo.setOnClickListener(this);
		backLayout=(RelativeLayout) view.findViewById(R.id.backLayout);
		backLayout.setOnClickListener(this);

		tv_setting = (TextView) view.findViewById(R.id.tv_header_back_text);
		tv_setting.setOnClickListener(this);
		tv_setting.setVisibility(View.INVISIBLE);
		
		TextView tv_common = (TextView) view.findViewById(R.id.tv_common);
		tv_common.setOnClickListener(this);
		
		et_login_username=(EditText)view.findViewById(R.id.et_login_username);
		et_login_password=(EditText)view.findViewById(R.id.et_login_password);
	}

	@Override
	public void onClick(View v) {

		switch (v.getId()) {
		
		case R.id.backLayout:
			startActivity(new Intent(getActivity(), LandingActivity.class));
			getActivity().finish();			
			break;
		case R.id.iv_back:
			startActivity(new Intent(getActivity(), LandingActivity.class));
			getActivity().finish();			
			break;
		case R.id.iv_top_logo:
			startActivity(new Intent(getActivity(), LandingActivity.class));
			getActivity().finish();
			break;

		case R.id.tv_forgot_pass:
			mFragement = new ForgotPasswordFragment();
			changeFragmentView(mFragement);			
			break;
		
		case R.id.tv_common:
			String strUserName=et_login_username.getText().toString().trim();
			String strpassword=et_login_password.getText().toString().trim();
			String strRequestPattern="{\"type\":\"auth\",\"user\":\""+strUserName+"\",\"pwd\":\""+strpassword+"\",\"id\":\"msgid\"}";
		Log.i("pattern", strRequestPattern);
		
		
		if(ConnectionDetector.isConnectingToInternet(activity)){
			WebSocketHelper.sendRequest(strRequestPattern,Appconstants.CLASS_LOGIN_HELPER);
		}else{
			Toast.makeText(activity,"No internet connection" ,0).show();
		}
				
			break;
			
		default:
			break;
		}
	}
	
	public  void goNext(){
		/*	mFragement = new LoginVerificationHelper();
			changeFragmentView(mFragement);*/
			
		getActivity().startActivity(new Intent(getActivity(), MainActivity.class));
		getActivity().finish();	
		//AppUtils.startSettingTab(getActivity());
			
		}
	
	public static void doAction(JSONObject jo){
		try {
			int strResponse = jo.getInt("code");
			Log.i("response code is : ", "" + strResponse);
			switch (strResponse) {
			case 0:
				activity.startActivity(new Intent(activity, MainActivity.class));
				activity.finish();	
				break;
			case 53:				
				Toast.makeText(activity,
						Appconstants.hmErrorCodes.get(strResponse), 0).show();
				break;
			
			case 58:
				
				Toast.makeText(activity,
						Appconstants.hmErrorCodes.get(strResponse), 0).show();
				break;

			default:
				Toast.makeText(activity,
						Appconstants.hmErrorCodes.get(strResponse), 0).show();
				break;
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
	private void changeFragmentView(Fragment fragment) {
		FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
		FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
		fragmentTransaction.replace(android.R.id.content, fragment);
		fragmentTransaction.commit();
	}
	
	

}
