package com.iamxam.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.iamxam.R;
import com.iamxam.activity.MainActivity;
import com.iamxam.appconstant.Appconstants;

public class ContactDeatilFragment extends Fragment implements OnClickListener{

	private TextView tv_setting;
	private ImageView iv_header_back;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_contact_detail_chat, container, false);
		initiliaseHeaderLayout(view);
		return view;
	}

	private void initiliaseHeaderLayout(View view) {

		iv_header_back = (ImageView) view.findViewById(R.id.iv_back);		
		iv_header_back.setOnClickListener(this);

		tv_setting = (TextView) view.findViewById(R.id.tv_header_back_text);
		tv_setting.setText(R.string.txt_tab_contact);
		tv_setting.setOnClickListener(this);
		tv_setting.setVisibility(View.VISIBLE);

		TextView tv_common = (TextView) view.findViewById(R.id.tv_common);
		tv_common.setText(R.string.txt_xml_send);
		tv_common.setTextColor(getResources().getColor(R.color.c_gray_light));

		TextView tv_header = (TextView) view.findViewById(R.id.tv_header);
		tv_header.setText(R.string.txt_xml_detail);
	}

	@Override
	public void onClick(View v) {

		switch (v.getId()) {
		case R.id.iv_back:
			tv_setting.setVisibility(View.GONE);		
			changeFragmentView();			
			break;

		case R.id.tv_header_back_text:			
			changeFragmentView();
		default:
			break;
		}
	}

	private void changeFragmentView() {

		Intent intent = new Intent(getActivity(), MainActivity.class);
		intent.putExtra(Appconstants.TO_WHICH_TAB, 2);
		getActivity().startActivity(intent);
		getActivity().finish();

	}
}
