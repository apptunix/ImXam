package com.iamxam.fragments;

import java.util.ArrayList;
import java.util.List;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.iamxam.R;
import com.iamxam.adapter.ExampleContactAdapter;
import com.iamxam.apputils.AppUtils;
import com.iamxam.models.ExampleDataSource;
import com.iamxam.second.widget.ContactItemInterface;
import com.iamxam.view.ExampleContactListView;

public class MyCircleSettingFragment extends Fragment implements OnClickListener{

	private ExampleContactListView listview;
	private Fragment mFragement;
	private TextView tv_setting;
	private ImageView iv_header_back;
	
	List<ContactItemInterface> contactList;
	List<ContactItemInterface> filterList;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_setting_mycircle, container, false);	
		initiliaseHeaderLayout(view);
		initialiseLayoutVariable(view);
		return view;
	}

	
	private void initialiseLayoutVariable(View view) {
		filterList = new ArrayList<ContactItemInterface>();
		contactList = ExampleDataSource.getSampleContactList();
		
		ExampleContactAdapter adapter = new ExampleContactAdapter(getActivity(), R.layout.example_contact_item, contactList);
		
		listview = (ExampleContactListView) view.findViewById(R.id.lv_mycircle);
		listview.setFastScrollEnabled(true);
		listview.setAdapter(adapter);		
	
	}
	private void initiliaseHeaderLayout(View view) {

		iv_header_back = (ImageView) view.findViewById(R.id.iv_back);
		iv_header_back.setOnClickListener(this);

		tv_setting = (TextView) view.findViewById(R.id.tv_header_back_text);
		tv_setting.setOnClickListener(this);
		tv_setting.setVisibility(View.VISIBLE);

		TextView tv_common = (TextView) view.findViewById(R.id.tv_common);
		tv_common.setText("25");

		TextView tv_header = (TextView) view.findViewById(R.id.tv_header);
		tv_header.setText(R.string.txt_setting_my_circle);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.iv_back:
			tv_setting.setVisibility(View.GONE);		
			AppUtils.startSettingTab(getActivity());			
			break;
		
		case R.id.tv_header_back_text:			
			AppUtils.startSettingTab(getActivity());
		default:
			break;
		}
	}


	private void changeFragmentView() {


		mFragement = new SettingFragement();
		FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
		FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
		fragmentTransaction.replace(android.R.id.content, mFragement);
		fragmentTransaction.commit();
	}
}
