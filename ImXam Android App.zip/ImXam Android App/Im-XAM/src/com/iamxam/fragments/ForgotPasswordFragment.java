package com.iamxam.fragments;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.iamxam.R;
import com.iamxam.appconstant.Appconstants;
import com.iamxam.websockethelper.WebSocketHelper;


public class ForgotPasswordFragment extends Fragment implements OnClickListener{

	private Fragment mFragement;
	private TextView tv_setting,tv_forgot_pass,tv_send_username;
	RelativeLayout backLayout;
	EditText et_forgot_password;
	static Activity activity;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_forget_password, container, false);
		initiliaseHeaderLayout(view);
		activity=getActivity();
		
		tv_forgot_pass.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				//go to password reset screen
				
				
				
				mFragement = new ChangePasswordSettingFragment();
			
				
				FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
				FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
				fragmentTransaction.replace(android.R.id.content, mFragement);
				fragmentTransaction.commit();
			}
		});
		
		tv_send_username.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String strForgotPassEmail=et_forgot_password.getText().toString().trim();
				String strRequestPattern="{\"type\":\"reg\",\"user\":\"user1\",\"email\":\""+strForgotPassEmail+"\",\"id\":\"msgid\"}";
				//must be uncomment
				//WebSocketHelper.sendRequest(strRequestPattern, Appconstants.CLASS_LOGIN_VERIFICATION);
			}
		});
		
		return view;
	}



	private void initiliaseHeaderLayout(View view) {

		ImageView iv_header_back = (ImageView) view.findViewById(R.id.iv_back);
		iv_header_back.setOnClickListener(this);
		ImageView iv_top_logo = (ImageView) view.findViewById(R.id.iv_top_logo);
		iv_top_logo.setOnClickListener(this);
		backLayout=(RelativeLayout) view.findViewById(R.id.backLayout);
		backLayout.setOnClickListener(this);

		tv_setting = (TextView) view.findViewById(R.id.tv_header_back_text);
		tv_setting.setOnClickListener(this);
		tv_setting.setText("Log In");
		tv_setting.setVisibility(View.VISIBLE);
		et_forgot_password=(EditText)view.findViewById(R.id.et_forgot_password);
		tv_forgot_pass=(TextView)view.findViewById(R.id.tv_forgot_pass);
		tv_send_username=(TextView)view.findViewById(R.id.tv_send_username);
		

		view.findViewById(R.id.tv_common).setVisibility(View.INVISIBLE);
		TextView tv_header = (TextView) view.findViewById(R.id.tv_header);
		//tv_header.setText(R.string.txt_xml_reste_pass);
		tv_header.setVisibility(View.INVISIBLE);
	}

	private void changeFragmentView() {
		mFragement = new LoginHelper();
		FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
		FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
		fragmentTransaction.replace(android.R.id.content, mFragement);
		fragmentTransaction.commit();
	}

	//call from "WebSocketHelper" class when receive response from web socket
			public static void doAction(JSONObject jo){
				try {
				String strResponse = jo.getString("code");			
				if(strResponse.equals("2")){										
					//goNext();		
					Toast.makeText(activity, "Password have been sent to entered email address", 0).show();
				}else{
					Toast.makeText(activity, "temp error", 0).show();
				}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 }

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		
		case R.id.backLayout:
			tv_setting.setVisibility(View.GONE);		
			changeFragmentView();			
			break;
		case R.id.iv_back:
			tv_setting.setVisibility(View.GONE);		
			changeFragmentView();			
			break;
		
		case R.id.iv_top_logo:
			tv_setting.setVisibility(View.GONE);		
			changeFragmentView();			
			break;
			
		case R.id.tv_header_back_text:			
			changeFragmentView();
		default:
			break;
		}
		
	}
}
