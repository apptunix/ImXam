package com.iamxam.fragments;

import java.util.ArrayList;
import java.util.List;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Toast;

import com.iamxam.R;
import com.iamxam.activity.MainActivity;
import com.iamxam.adapter.ExampleContactAdapter;
import com.iamxam.models.ExampleContactItem;
import com.iamxam.models.ExampleDataSource;
import com.iamxam.second.widget.ContactItemInterface;
import com.iamxam.view.ExampleContactListView;

public class ContactFragment extends android.support.v4.app.Fragment implements
		TextWatcher, OnClickListener {

	private ExampleContactListView listview;

	private EditText searchBox;
	private String searchString;

	private Object searchLock = new Object();
	boolean inSearchMode = false;

	private final static String TAG = "ContactFragment";
	List<ContactItemInterface> contactList;
	List<ContactItemInterface> filterList;
	private SearchListTask curSearchTask = null;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.contact_list, container, false);
		initialiseLayoutVariable(view);
	   MainActivity.clrEditText();
		return view;
	}

	public static ContactFragment newInstance() {
		ContactFragment fragment = new ContactFragment();
		return fragment;
	}

	private void initialiseLayoutVariable(View view) {
		filterList = new ArrayList<ContactItemInterface>();
		contactList = ExampleDataSource.getSampleContactList();

		ExampleContactAdapter adapter = new ExampleContactAdapter(
				getActivity(), R.layout.example_contact_item, contactList);

		listview = (ExampleContactListView) view.findViewById(R.id.listview);
		listview.setFastScrollEnabled(true);
		listview.setAdapter(adapter);

		listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView parent, View v, int position,
					long id) {

				List<ContactItemInterface> searchList = inSearchMode ? filterList
						: contactList;

				float lastTouchX = listview.getScroller()
						.getLastTouchDownEventX();

				Log.e(TAG, String.valueOf(lastTouchX));
				if (lastTouchX < 62 && lastTouchX > -1) {
					Toast.makeText(
							getActivity(),
							"User image is clicked ( "
									+ searchList.get(position)
											.getItemForIndex() + ")",
							Toast.LENGTH_SHORT).show();
				} else if (lastTouchX > 62 && lastTouchX < 524) {
					Fragment mFragement = new ContactDeatilFragment();
					FragmentManager fragmentManager = getActivity()
							.getSupportFragmentManager();
					FragmentTransaction fragmentTransaction = fragmentManager
							.beginTransaction();
					fragmentTransaction.replace(android.R.id.content,
							mFragement);
					fragmentTransaction.commit();
				} else {

					Toast.makeText(getActivity(), "Button  Clicked",
							Toast.LENGTH_SHORT).show();
					Toast.makeText(
							getActivity(),
							"button clicked: "
									+ searchList.get(position)
											.getItemForIndex(),
							Toast.LENGTH_SHORT).show();
				}

			}
		});

		// searchBox = (EditText) view.findViewById(R.id.input_search_query);
		MainActivity.edt_search.addTextChangedListener(this);
		MainActivity.edt_search.setFocusable(true);
	}

	private class SearchListTask extends AsyncTask<String, Void, String> {

		@Override
		protected String doInBackground(String... params) {
			filterList.clear();

			String keyword = params[0];

			inSearchMode = (keyword.length() > 0);

			if (inSearchMode) {
				// get all the items matching this
				for (ContactItemInterface item : contactList) {
					ExampleContactItem contact = (ExampleContactItem) item;

					if ((contact.getFullName().toUpperCase().indexOf(keyword) > -1)) {
						filterList.add(item);
					}

				}

			}
			
			return null;
		}

		protected void onPostExecute(String result) {

			synchronized (searchLock) {

				if (inSearchMode) {

					ExampleContactAdapter adapter = new ExampleContactAdapter(
							getActivity(), R.layout.example_contact_item,
							filterList);
					adapter.setInSearchMode(true);

					listview.setInSearchMode(true);
					listview.setAdapter(adapter);
					

				} else {
					ExampleContactAdapter adapter = new ExampleContactAdapter(
							getActivity(), R.layout.example_contact_item,
							contactList);
					adapter.setInSearchMode(false);
					listview.setInSearchMode(false);
					listview.setAdapter(adapter);

				}
			}

		}
	}

	@Override
	public void beforeTextChanged(CharSequence s, int start, int count,
			int after) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
		// TODO Auto-generated method stub

	}

	@Override
	public void afterTextChanged(Editable s) {
		searchString = MainActivity.edt_search.getText().toString().trim()
				.toUpperCase();

		if (curSearchTask != null
				&& curSearchTask.getStatus() != AsyncTask.Status.FINISHED) {
			try {
				curSearchTask.cancel(true);
			} catch (Exception e) {
				Toast.makeText(getActivity(), contactList.size(),
						Toast.LENGTH_SHORT).show();
				Log.i(TAG, "Fail to cancel running search task");

			}

		}
		curSearchTask = new SearchListTask();
		curSearchTask.execute(searchString);

	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub

	}

	/*
	 * @Override public void onResume() { super.onResume(); getResources();
	 * MainActivity.edt_search.addTextChangedListener(new TextWatcher() {
	 * 
	 * @Override public void onTextChanged(CharSequence cs, int arg1, int arg2,
	 * int arg3) { // When user changed the Text }
	 * 
	 * @Override public void beforeTextChanged(CharSequence arg0, int arg1, int
	 * arg2, int arg3) { // TODO Auto-generated method stub
	 * 
	 * }
	 * 
	 * @Override public void afterTextChanged(Editable s) {
	 * 
	 * System.out
	 * .println("111111111111111111111111111111111111111111111111111111111111111"
	 * );
	 * 
	 * if (search_data.size() != 0) { search_data.clear(); }
	 * 
	 * String Serach = s.toString();
	 * 
	 * if (s.toString().length() != 0) { // TODO Auto-generated method stub for
	 * (int i = 0; i < contactList.size(); i++) {
	 * 
	 * if ((contactList.get(i).getItemForIndex() .contains(Serach.toString())))
	 * { search_data.add(contactList.get(i).getItemForIndex()); }
	 * 
	 * }
	 * 
	 * 
	 * adapter = new ExampleContactAdapter(getActivity(),
	 * R.layout.example_contact_item, contactList);
	 * 
	 * 
	 * 
	 * listview.setAdapter(adapter);
	 * 
	 * 
	 * // adapter = new SettingsCustomAdapter(CustomListView, //
	 * search_data,res);
	 * 
	 * // list.setAdapter(adapter);
	 * 
	 * }
	 * 
	 * else{ adapter = new ExampleContactAdapter(getActivity(),
	 * R.layout.example_contact_item, contactList);
	 * 
	 * 
	 * listview.setFastScrollEnabled(true); listview.setAdapter(adapter);
	 * 
	 * 
	 * 
	 * }
	 * 
	 * }
	 * 
	 * });
	 * 
	 * 
	 * 
	 * 
	 * 
	 * }
	 * 
	 * @Override public void afterTextChanged(Editable arg0) { // TODO
	 * Auto-generated method stub
	 * 
	 * }
	 * 
	 * @Override public void beforeTextChanged(CharSequence s, int start, int
	 * count, int after) { // TODO Auto-generated method stub
	 * 
	 * }
	 * 
	 * @Override public void onTextChanged(CharSequence s, int start, int
	 * before, int count) { // TODO Auto-generated method stub
	 * 
	 * }
	 */

}
