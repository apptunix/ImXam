package com.iamxam.fragments;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.iamxam.R;
import com.iamxam.gettersetter.UserChatDetailData;

public class UserChatDetail extends Fragment implements OnClickListener{

	

	private ListView mListView;
	private RelativeLayout mQuickReturnView;
	private static String strUsername;
	
	
	public static UserChatDetail newInstance(String strUName){
		UserChatDetail chat = new UserChatDetail();
		strUsername=strUName;
		return chat;
	}
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_chat_detail_screen, container, false);
		mQuickReturnView = (RelativeLayout) view.findViewById(R.id.ll_conatin_sending_controls);
		mListView = (ListView)view.findViewById(R.id.list_chat_detail);

		initialiseLayoutVariables(view);
		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {

		super.onActivityCreated(savedInstanceState);

				
		
		List<UserChatDetailData> list = new ArrayList<UserChatDetailData>();
		for(int i=0;i<10;i++){
			UserChatDetailData objUserChatDetailData = new UserChatDetailData(); 
			if(i%2==0){
			objUserChatDetailData.setStrUserName(strUsername);
			}else{
				objUserChatDetailData.setStrUserName("me");
			}
			objUserChatDetailData.setStrUserMessage("I won't be able to come");
			objUserChatDetailData.setStrCurrentTime("3:21 PM");
			
			list.add(objUserChatDetailData);
		}


		UserChatDetailAdapter mUserAdapter = new UserChatDetailAdapter(getActivity(), list);
		mListView.setAdapter(mUserAdapter);

	}


	private void initialiseLayoutVariables(View view) {
		view.findViewById(R.id.btn_add_attachment).setOnClickListener(this);
		view.findViewById(R.id.btn_send_message).setOnClickListener(this);
		view.findViewById(R.id.btn_tick).setOnClickListener(this);
		
		view.findViewById(R.id.iv_detail_back).setOnClickListener(this);


	}


	@Override
	public void onClick(View v) {

		switch (v.getId()) {
		
		case R.id.btn_add_attachment:
			Log.i("btn", "attachment");
			break;						
		case R.id.btn_send_message:	
			Log.i("btn", "send message");
			break;
		case R.id.btn_tick:	
			Log.i("btn", "tick");
			break;
		case R.id.iv_detail_back:	
			Log.i("btn", "back");
			getActivity().getSupportFragmentManager().beginTransaction().remove(this).commit();
			break;

		default:
			break;
		}
	}


	


	public class UserChatDetailAdapter extends BaseAdapter{

		Activity act;
		List<UserChatDetailData> list;
		public UserChatDetailAdapter(Activity act, List<UserChatDetailData> list){
			this.act = act;
			this.list = list;
		}

		@Override
		public int getCount() {
			return list.size();
		}

		@Override
		public Object getItem(int position) {
			return position;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {

			if (convertView == null) {
				convertView = LayoutInflater.from(act).inflate(R.layout.row_chat_detail_message_view, parent, false);
			}
			TextView tvName = (TextView) convertView.findViewById(R.id.tv_user_message_nick_name);
			TextView tvMessage = (TextView) convertView.findViewById(R.id.tv_user_message_full_desc);
			TextView tvCurrentTime = (TextView) convertView.findViewById(R.id.tv_user_message_time_updated);
			TextView tvPreviousTime = (TextView) convertView.findViewById(R.id.tv_user_message_time_orignal);
			ImageView iv_image_front_of_user=(ImageView)convertView.findViewById(R.id.iv_user_message_user_color);
			ImageView iv_image_msg=(ImageView)convertView.findViewById(R.id.iv_user_message_img_data);
			Button btn_like=(Button)convertView.findViewById(R.id.btn_user_message_like);
			Button btn_forward=(Button)convertView.findViewById(R.id.btn_user_message_forward);
			
			if(list.get(position).getStrUserName().toString().equals("me")){
				iv_image_front_of_user.setImageResource(Color.parseColor("#850B27"));
				tvName.setTextColor(Color.parseColor("#850B27"));
			}else{
				iv_image_front_of_user.setImageResource(Color.parseColor("#057313"));
				tvName.setTextColor(Color.parseColor("#057313"));
			}
			tvName.setText(list.get(position).getStrUserName());
			tvMessage.setText(list.get(position).getStrUserMessage());
			tvCurrentTime.setText(list.get(position).getStrCurrentTime());
			
		
			return convertView;
		}

	}	
	
}
