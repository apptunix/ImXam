package com.iamxam.fragments;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.iamxam.R;

@SuppressLint("NewApi")
public class SettingFragement extends Fragment implements OnClickListener{
	private Fragment mFragement;
	private TextView tv_common;
	private AlertDialog levelDialog;

	final CharSequence[] qvite_reminder = {" 2 Hours "," 4 Hours "," 1 Day "," Custom "};
	final CharSequence[] vote_reminder = {" 5 Minutes "," 15 Minutes "," 30 Minutes "," Custom "};


	public static SettingFragement newInstance(){
		SettingFragement settingFragment = new SettingFragement();
		return settingFragment;
	}
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_setting_layout, container, false);
		//initiliaseHeaderLayout(view);
		initiliaseLayoutVariables(view);
		return view;
	}

	private void initiliaseLayoutVariables(View view) {

		RelativeLayout rl_profile_setting, rl_setting_notification, rl_setting_ch_password, rl_setting_about, rl_setting_qvite_rmnder, rl_setting_vote_rmnder, 
		rl_setting_mycircle, rl_setting_block_contact, rl_setting_qvite, rl_setting_vote;


		rl_setting_qvite = (RelativeLayout) view.findViewById(R.id.rl_setting_qvite);
		rl_setting_qvite.setOnClickListener(this);

		rl_setting_vote = (RelativeLayout) view.findViewById(R.id.rl_setting_vote);
		rl_setting_vote.setOnClickListener(this);

		rl_setting_block_contact = (RelativeLayout) view.findViewById(R.id.rl_setting_block_contact);
		rl_setting_block_contact.setOnClickListener(this);

		rl_profile_setting = (RelativeLayout) view.findViewById(R.id.rl_profile_setting);
		rl_profile_setting.setOnClickListener(this);

		rl_setting_notification = (RelativeLayout) view.findViewById(R.id.rl_setting_notification);
		rl_setting_notification.setOnClickListener(this);

		rl_setting_ch_password = (RelativeLayout) view.findViewById(R.id.rl_setting_ch_password);
		rl_setting_ch_password.setOnClickListener(this);

		rl_setting_about = (RelativeLayout) view.findViewById(R.id.rl_setting_about);
		rl_setting_about.setOnClickListener(this);

		rl_setting_vote_rmnder = (RelativeLayout) view.findViewById(R.id.rl_setting_vote_reminder);
		rl_setting_vote_rmnder.setOnClickListener(this);

		rl_setting_qvite_rmnder = (RelativeLayout) view.findViewById(R.id.rl_setting_qvite_reminder);
		rl_setting_qvite_rmnder.setOnClickListener(this);

		rl_setting_mycircle = (RelativeLayout) view.findViewById(R.id.rl_setting_mycircle);
		rl_setting_mycircle.setOnClickListener(this);

	}

	private void initiliaseHeaderLayout(View view) {

		ImageView iv_header_back = (ImageView) view.findViewById(R.id.iv_back);
		//iv_header_back.setOnClickListener(this);
		iv_header_back.setVisibility(View.INVISIBLE);
		TextView tv_header = (TextView) view.findViewById(R.id.tv_header);
		tv_header.setText(R.string.menu_settings);;

		tv_common = (TextView) view.findViewById(R.id.tv_common);
		tv_common.setVisibility(View.GONE);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.iv_back:	
			tv_common.setVisibility(View.VISIBLE);
			mFragement = new LoginHelper();
			changeFragmentView(mFragement);			
			break;

		case R.id.rl_profile_setting:
			mFragement = new ProfileSettingFragment();
			changeFragmentView(mFragement);
			break;
		case R.id.rl_setting_notification:
			mFragement = new NotificationSettingFragment();
			changeFragmentView(mFragement);
			break;
		case R.id.rl_setting_ch_password:
			mFragement = new ChangePasswordSettingFragment();
			changeFragmentView(mFragement);
			break;

		case R.id.rl_setting_about:
			mFragement = new AboutSettingFragment();
			changeFragmentView(mFragement);
			break;

		case R.id.rl_setting_qvite_reminder:
			
			showDialog(qvite_reminder);
			/*mFragement = new QviteReminder();
			changeFragmentView(mFragement);*/
			break;

		case R.id.rl_setting_vote_reminder:
			
			showDialog(vote_reminder);
			/*mFragement = new VoteReminder();
			changeFragmentView(mFragement);*/
			break;

		case R.id.rl_setting_mycircle:
			mFragement = new MyCircleSettingFragment();
			changeFragmentView(mFragement);
			break;

		case R.id.rl_setting_block_contact:
			mFragement = new BlockContactSettingFragment();
			changeFragmentView(mFragement);
			break;

		case R.id.rl_setting_qvite:
			mFragement = new ManageQviteSettingFragment();
			changeFragmentView(mFragement);
			break;

		case R.id.rl_setting_vote:
			mFragement = new ManageVoteSettingFragment();
			changeFragmentView(mFragement);
			break;
		default:
			break;
		}

	}



	public void showDialog(CharSequence[] items)
	{

		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
		builder.setTitle("Select time for reminder.");
		builder.setCancelable(true);
		builder.setSingleChoiceItems(items, -1, new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int item) {


				switch(item)
				{
				case 0:
					// Your code when first option seletced
					break;
				case 1:
					// Your code when 2nd  option seletced

					break;
				case 2:
					// Your code when 3rd option seletced
					break;
				case 3:
					// Your code when 4th  option seletced            
					break;

				}
				//levelDialog.dismiss();    
			}
		});
		levelDialog = builder.create();
		levelDialog.show();

	}
	private void changeFragmentView(Fragment fragment) {
		FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
		FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
		fragmentTransaction.replace(android.R.id.content, fragment);
		fragmentTransaction.commit();
	}
}
