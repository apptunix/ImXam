package com.iamxam.appconstant;

import java.util.HashMap;

public class Appconstants {

	public static final String WEBSOCKETURI="wss://app.imxam.com/websocket";
	public static final String INTENT_FROM = "from";
	public static final String LOGIN = "login";
	public static final String SIGNUP = "signup";
	
	public static final String TO_WHICH_TAB = "whichTab";	
	public static final int ALERT = 1;
	public static final int CONTACT = ALERT + 1;
	public static final int CHAT = CONTACT + 1;
	public static final int SETTING = CHAT + 1;
	
	//pattern for sign up screen EditTexts
	public static final String PATTERN_NAME = "[a-zA-Z ]*";
	public static final String PATTERN_USERNAME = "[0-9a-zA-Z_ ]*";
	public static final String PATTERN_EMAIL = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
	
	//Constants for error codes
	public static final HashMap<Integer,String> hmErrorCodes;
	
	//Constants for classnames
	public static final String CLASS_SIGNUP_HELPER = "Signuphelper";
	public static final String CLASS_LOGIN_HELPER = "LoginHelper";
	public static final String CLASS_LOGIN_VERIFICATION = "LoginVerificationHelper";
	public static final String CLASS_FORGOT_PASSWORD = "ForgotPasswordFragment";
	
	//hashmap stores classnames as key and a integer value(see switch case in WebSocketHelper's "onTextMessage()")
	public static final HashMap<String,Integer> hmClassNames;
	static{
		//set values for class names
		hmClassNames=new HashMap<String,Integer>();
		hmClassNames.put(CLASS_SIGNUP_HELPER, 1);
		hmClassNames.put(CLASS_LOGIN_HELPER, 2);
		hmClassNames.put(CLASS_LOGIN_VERIFICATION, 3);
		hmClassNames.put(CLASS_FORGOT_PASSWORD, 4);
		
		
		//set values for error codes
		hmErrorCodes=new HashMap<Integer, String>();
		hmErrorCodes.put(58,"User is not authorized");
		hmErrorCodes.put(53,"Please use correct User Name and Password");
	}
	
}
