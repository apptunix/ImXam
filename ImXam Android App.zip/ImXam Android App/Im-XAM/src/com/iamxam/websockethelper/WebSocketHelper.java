package com.iamxam.websockethelper;

import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.iamxam.appconstant.Appconstants;
import com.iamxam.fragments.ForgotPasswordFragment;
import com.iamxam.fragments.LoginHelper;
import com.iamxam.fragments.LoginVerificationHelper;
import com.iamxam.fragments.Signuphelper;

import de.tavendo.autobahn.WebSocket;
import de.tavendo.autobahn.WebSocketConnection;
import de.tavendo.autobahn.WebSocketConnectionHandler;
import de.tavendo.autobahn.WebSocketException;

public class WebSocketHelper {
	
	//integer value corresponding to class name stored in hashmap(AppConstants class)
	public static int strClassName=0;
	
	 public static final WebSocket mConnection1 = new WebSocketConnection();
		 
	 public static void makeConnection() {

	      final String wsuri = Appconstants.WEBSOCKETURI;


	      try {
	         mConnection1.connect(wsuri, new WebSocketConnectionHandler() {
	            @Override
	            public void onOpen() {
	            	 Log.d("ImXam","open");
	            }

	            @Override
	            public void onTextMessage(String payload) {
	              // alert("Got echo: " + payload);
	            	try {
	            		JSONObject jo=new JSONObject(payload);
						switch(strClassName){
						case 1:
							Signuphelper.doAction(jo);
							break;
						case 2:
							LoginHelper.doAction(jo);
							break;
						case 3:
							LoginVerificationHelper.doAction(jo);
							break;
						case 4:
							ForgotPasswordFragment.doAction(jo);
							break;
							
						default:							
							break;
						}					
	            		
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}             	
	            }

	            @Override
	            public void onClose(int code, String reason) {
	            	 Log.d("ImXam", "close");
	            }
	         });
	      } catch (WebSocketException e) {

	         Log.d("ImXam", e.toString());
	      }
	   }
	 
	 public static void sendRequest(String payload,String strClass){
			//get the integer value from hashmap of class names created in AppConstants class
			if(strClass.equals(Appconstants.CLASS_SIGNUP_HELPER)){
				strClassName=Appconstants.hmClassNames.get(Appconstants.CLASS_SIGNUP_HELPER);
			}else if (strClass.equals(Appconstants.CLASS_LOGIN_HELPER)) {
				strClassName=Appconstants.hmClassNames.get(Appconstants.CLASS_LOGIN_HELPER);
			}else if (strClass.equals(Appconstants.CLASS_LOGIN_VERIFICATION)) {
				strClassName=Appconstants.hmClassNames.get(Appconstants.CLASS_LOGIN_VERIFICATION);
			}else if (strClass.equals(Appconstants.CLASS_FORGOT_PASSWORD)) {
				strClassName=Appconstants.hmClassNames.get(Appconstants.CLASS_FORGOT_PASSWORD);
			}
			mConnection1.sendTextMessage(payload);
		}
	 
	}
