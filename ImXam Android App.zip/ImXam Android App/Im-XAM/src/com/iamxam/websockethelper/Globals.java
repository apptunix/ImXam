package com.iamxam.websockethelper;

import java.io.Serializable;

public class Globals implements Serializable{
	public static Object objGlobals = new Object();
}
