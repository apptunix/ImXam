package com.iamxam.parser;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;

public class SetParsedResponse extends AsyncTask<String, String, String>{
	public static JSONObject objResponse=null;
	Context c;
	public void SetParsedResponse(Context context){
		c=context;
	}

	private ProgressDialog progressDialog;
	@Override
	protected void onPreExecute() {
		// TODO Auto-generated method stub
		 progressDialog = new ProgressDialog(c);
	        progressDialog.setMessage("Loading...");
	        progressDialog.setCancelable(false);
	        progressDialog.show();
		super.onPreExecute();
	}
	@Override
	protected String doInBackground(String... params) {
		// TODO Auto-generated method stub
		try {
			objResponse=new JSONObject(params[0]);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	@Override
	protected void onPostExecute(String result) {
		// TODO Auto-generated method stub
		 if (progressDialog.isShowing()) {
	            progressDialog.dismiss();
	        }
		super.onPostExecute(result);
	}

	

}
