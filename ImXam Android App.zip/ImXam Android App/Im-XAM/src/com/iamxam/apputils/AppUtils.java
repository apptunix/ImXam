package com.iamxam.apputils;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

import com.iamxam.activity.MainActivity;
import com.iamxam.appconstant.Appconstants;

public class AppUtils {

	/*This function is used for drawable decode 
	 *  to remove out of memory issue for drawable  */
	public static Drawable getAssetImage(Context context, String filename) throws IOException {
	    AssetManager assets = context.getResources().getAssets();
	    InputStream buffer = new BufferedInputStream((assets.open("drawable/" + filename + ".jpg")));
	    Bitmap bitmap = BitmapFactory.decodeStream(buffer);
	    return new BitmapDrawable(context.getResources(), bitmap);
	}
	
	
	public static void startSettingTab(Activity activity){
		
		Intent intent = new Intent(activity, MainActivity.class);
		intent.putExtra(Appconstants.TO_WHICH_TAB, 3);
		activity.startActivity(intent);
		activity.finish();
		
	}
}
