package com.iamxam.models;

public class BeanCountryCode {
String Country,AlphaCode,Country_code;

public String getCountry() {
	return Country;
}

public void setCountry(String country) {
	Country = country;
}

public String getAlphaCode() {
	return AlphaCode;
}

public void setAlphaCode(String alphaCode) {
	AlphaCode = alphaCode;
}

public String getCountry_code() {
	return Country_code;
}

public void setCountry_code(String country_code) {
	Country_code = country_code;
}
}
