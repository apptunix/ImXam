package com.iamxam.application;



import android.app.Application;

public class IAmXamApplication extends Application {
	@Override
	public void onCreate() {
		super.onCreate();
		
	}

}
