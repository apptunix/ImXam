package com.iamxam.adapter;

import java.util.List;

import com.iamxam.R;
import com.iamxam.gettersetter.UserMessageData;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class UserAdapter extends ArrayAdapter<UserMessageData> {

	List<UserMessageData> data;
	Context context;
	int layoutResID;

	public UserAdapter(Context context, int layoutResourceId, List<UserMessageData> data) {
		super(context, layoutResourceId, data);

		this.data = data;
		this.context = context;
		this.layoutResID = layoutResourceId;

		// TODO Auto-generated constructor stub
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		NewsHolder holder = null;
		View row = convertView;
		holder = null;

		if (row == null) {
			LayoutInflater inflater = ((Activity) context).getLayoutInflater();
			row = inflater.inflate(layoutResID, parent, false);

			holder = new NewsHolder();
			holder.tvName = (TextView) row
					.findViewById(R.id.tv_chat_row_nick_name);
			holder.tv_chat_row_full_desc = (TextView) row
					.findViewById(R.id.tv_chat_row_full_desc);
			holder.tv_chat_row_time = (TextView) row
					.findViewById(R.id.tv_chat_row_time);
			holder.tv_chat_row_badge = (TextView) row
					.findViewById(R.id.tv_chat_row_badge);
			holder.iv_chat_row_user_image = (ImageView) row
					.findViewById(R.id.iv_chat_row_user_image);

			holder.button1 = (Button) row.findViewById(R.id.swipe_button1);

			row.setTag(holder);
		} else {
			holder = (NewsHolder) row.getTag();
		}

		UserMessageData itemdata = data.get(position);

		holder.tvName.setText(itemdata.getStrChatRow_NickName());
		holder.tv_chat_row_full_desc.setText(itemdata.getStrChatRow_FullDesc());
		holder.tv_chat_row_time.setText(itemdata.getStrChatRow_Time());
		holder.tv_chat_row_badge.setText(itemdata.getStrChatRow_Badge());
		holder.button1.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Toast.makeText(context, "Button 1 Clicked", Toast.LENGTH_SHORT)
						.show();
			}
		});

		return row;

	}

	static class NewsHolder {

		TextView itemName;
		ImageView icon;
		Button button1;
		TextView tvName;
		TextView tv_chat_row_full_desc;
		TextView tv_chat_row_time;
		TextView tv_chat_row_badge;
		ImageView iv_chat_row_user_image;

	}

}
