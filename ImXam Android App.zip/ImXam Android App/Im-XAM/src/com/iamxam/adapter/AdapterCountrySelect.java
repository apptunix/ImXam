package com.iamxam.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.support.v7.appcompat.R;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.iamxam.gettersetter.Country;

public class AdapterCountrySelect extends ArrayAdapter<Country> {
	
	ViewHolder holder;
	private LayoutInflater mLayoutInflater;
	int layout_id;
	Context context;
//	String strCountryName;
	ArrayList<Country> data;
//	public AdapterCountrySelect(Context context,String strCountry) {
//		super(context,0x7f030044);
//		this.context = context;
//		mLayoutInflater = LayoutInflater.from(context);
//		strCountryName=strCountry;
//		if(strCountryName!=null){
//		Log.i("constructor ", strCountryName);
//		}
//		// TODO Auto-generated constructor stub
//	}
	
	public AdapterCountrySelect(Context context,ArrayList<Country> data) {
		super(context,0x7f030045,data);
		this.context = context;
		mLayoutInflater = LayoutInflater.from(context);
		this.data=data;
//		strCountryName=data;
//		if(data!=null){
//		Log.i("constructor ", data.get(0).getName());
//		}
		// TODO Auto-generated constructor stub
	}
	
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		if (convertView == null) {
			convertView = mLayoutInflater.inflate(0x7f030045, parent, false);
			holder = new ViewHolder();
			holder.mImageView = (ImageView) convertView
					.findViewById(R.id.image);
			holder.mNameView = (TextView) convertView.findViewById(0x7f050124);
			holder.mCodeView = (TextView) convertView.findViewById(0x7f050125);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		Country country =data.get(position);
		Log.i("oooo ", country.getName());
		
		System.out.println(">>>>>>=="+country.getName());
		if (country != null) {
			
			Log.i("outside ", country.getName());
			holder.mNameView.setText(country.getName());
			holder.mCodeView.setText(country.getCountryCodeStr());
			holder.mImageView.setImageResource(country.getResId());
			
//			if(data.get(position).getName()!=null){
//				Log.i("call on change ", country.getName());
//				if(country.getName().startsWith(strCountryName)){
//					Log.i("inside ", country.getName());
//				holder.mNameView.setText(country.getName());
//				holder.mCodeView.setText(country.getCountryCodeStr());
//				holder.mImageView.setImageResource(country.getResId());
//				}
//			}else{
//				Log.i("outside ", country.getName());
//			holder.mNameView.setText(country.getName());
//			holder.mCodeView.setText(country.getCountryCodeStr());
//			holder.mImageView.setImageResource(country.getResId());
//			}
		}
		return convertView;
	}

	

	 private static class ViewHolder {
	        public ImageView mImageView;
	        public TextView mNameView;
	        public TextView mCodeView;
	    }
}
