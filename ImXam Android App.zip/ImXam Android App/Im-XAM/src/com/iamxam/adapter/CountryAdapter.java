/*
 * Copyright (c) 2014 Amberfog.
 *
 * This source code is Amberfog Confidential Proprietary
 * This software is protected by copyright. All rights and titles are reserved.
 * You shall not use, copy, distribute, modify, decompile, disassemble or reverse
 * engineer the software. Otherwise this violation would be treated by law and
 * would be subject to legal prosecution. Legal use of the software provides
 * receipt of a license from the right holder only.
 */

package com.iamxam.adapter;

import android.content.Context;

import android.support.v7.appcompat.R;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.iamxam.gettersetter.Country;

public class CountryAdapter extends ArrayAdapter<Country> {
   

	ViewHolder holder;
	private LayoutInflater mLayoutInflater;
	int layout_id;
	Context context;

	public CountryAdapter(Context context) {
		super(context, 0);
		this.context = context;
		mLayoutInflater = LayoutInflater.from(context);
		
	}

	/*public View getDropDownView(int position, View convertView, ViewGroup parent) {
		//final ViewHolder holder;
		if (convertView == null) {
			convertView = mLayoutInflater.inflate(0x7f030043, parent, false);
			holder = new ViewHolder();
			holder.mImageView = (ImageView) convertView
					.findViewById(R.id.image);
			holder.mNameView = (TextView) convertView.findViewById(0x7f05012a);
			holder.mCodeView = (TextView) convertView.findViewById(0x7f05012b);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		Country country = getItem(position);
		if (country != null) {
			holder.mNameView.setText(country.getName());
			holder.mCodeView.setText(country.getCountryCodeStr());
			holder.mImageView.setImageResource(country.getResId());
		}
		return convertView;
	}

	 public View getView(int position, View convertView, ViewGroup parent) {
		 Country country = getItem(position);
	        if (convertView == null) {
	            convertView = mLayoutInflater.inflate(0x7f030042, null);
	        }
	        ImageView imageView = (ImageView) convertView.findViewById(R.id.image);
	        TextView txt_cntry=(TextView)convertView.findViewById(0x7f050127);
	        TextView txt_code=(TextView)convertView.findViewById(0x7f050128);
	        txt_cntry.setText(country.getName());
	        txt_code.setText(country.getCountryCodeStr());
	        imageView.setImageResource(country.getResId());
	        return convertView;
		
	       
	    }*/

	  @Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
		  Country country = getItem(position);
	        if (convertView == null) {
	            convertView = mLayoutInflater.inflate(0x7f030043, null);
	        }
	        ImageView imageView = (ImageView) convertView.findViewById(R.id.image);
	        TextView txt_cntry=(TextView)convertView.findViewById(0x7f05012a);
	        TextView txt_code=(TextView)convertView.findViewById(0x7f05012b);
	        txt_cntry.setText(country.getName());
	        txt_code.setText(country.getCountryCodeStr());
	        imageView.setImageResource(country.getResId());
			return convertView;
		}

		@Override
		public View getDropDownView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			if (convertView == null) {
				convertView = mLayoutInflater.inflate(0x7f030044, parent, false);
				holder = new ViewHolder();
				holder.mImageView = (ImageView) convertView
						.findViewById(R.id.image);
				holder.mNameView = (TextView) convertView.findViewById(0x7f05012c);
				holder.mCodeView = (TextView) convertView.findViewById(0x7f05012d);
				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}
			Country country = getItem(position);
			if (country != null) {
				holder.mNameView.setText(country.getName());
				holder.mCodeView.setText(country.getCountryCodeStr());
				holder.mImageView.setImageResource(country.getResId());
			}
			return convertView;
		}
	    private static class ViewHolder {
	        public ImageView mImageView;
	        public TextView mNameView;
	        public TextView mCodeView;
	    }
	}
