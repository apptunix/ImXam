package com.iamxam.textwatcher;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.EditText;
import android.widget.Toast;

import com.iamxam.R;

public class GenericTextWatcher implements TextWatcher{

    private View view;
    public GenericTextWatcher(View view) {
        this.view = view;
    }
		
	


	@Override
	public void beforeTextChanged(CharSequence s, int start, int count,
			int after) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void afterTextChanged(Editable s) {
		// TODO Auto-generated method stub
		  switch(view.getId()){
          case R.id.et_signup_firstname:
        	  EditText et =(EditText)view.findViewById(R.id.et_signup_firstname);
        	  String input=et.getText().toString();
        	  boolean checkValid=input.matches("[a-zA-Z ]*");
        	  if(!checkValid){
              Toast.makeText(view.getContext(), "no special character allowed", 0).show();
              }
              break;
      }
		
	}
}